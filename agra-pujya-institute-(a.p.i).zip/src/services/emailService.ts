/**
 * Email Service for Agra Pujya Institute
 * Sends form submissions directly to agrapujyainstitute@gmail.com
 * (with CC to technicalprahalada@gmail.com)
 * using FormSubmit.co AJAX API with automatic inbox delivery.
 */

export const ADMIN_EMAIL = 'agrapujyainstitute@gmail.com';
export const CC_EMAIL = 'technicalprahalada@gmail.com';

export interface EmailPayload {
  _subject: string;
  [key: string]: string | number | boolean | undefined;
}

export async function sendEmailNotification(payload: EmailPayload): Promise<{ success: boolean; message: string }> {
  try {
    const response = await fetch(`https://formsubmit.co/ajax/${ADMIN_EMAIL}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        _template: 'table',
        _captcha: 'false',
        _cc: CC_EMAIL,
        _honey: '', // Anti-spam honeypot
        ...payload,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      return {
        success: true,
        message: data.message || `Notification sent to ${ADMIN_EMAIL}`,
      };
    } else {
      console.warn('FormSubmit returned non-ok status, using fallback', response.status);
      return {
        success: false,
        message: 'Could not send online email dispatch, data saved locally.',
      };
    }
  } catch (error) {
    console.warn('Network error while dispatching email notification:', error);
    return {
      success: false,
      message: 'Network offline or request blocked. Record safely stored in local database.',
    };
  }
}
