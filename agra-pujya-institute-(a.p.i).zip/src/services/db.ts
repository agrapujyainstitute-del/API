import {
  AdmissionApplication,
  VolunteerApplication,
  ContactMessage,
  EducationalProgram,
  GalleryItem,
  Announcement,
  SiteContent,
  StudentRecord,
  FeePaymentRecord,
} from '../types';

const STORAGE_KEYS = {
  APPLICATIONS: 'api_ngo_admission_applications_v3',
  VOLUNTEERS: 'api_ngo_volunteer_applications_v3',
  MESSAGES: 'api_ngo_contact_messages_v3',
  STUDENTS: 'api_ngo_students_v1',
  SITE_CONTENT: 'api_ngo_site_content_v10',
  GALLERY: 'api_ngo_gallery_items_v9',
  PROGRAMS: 'api_ngo_programs_v7',
  ANNOUNCEMENTS: 'api_ngo_announcements',
  ADMIN_AUTH: 'api_ngo_admin_authenticated',
  ADMIN_CREDS: 'api_ngo_admin_credentials_v2',
};

// Default initial authentic content strictly based on the reference page technicalprahalad.com/our-ngo-agra-pujya-institute/
export const DEFAULT_SITE_CONTENT: SiteContent = {
  organizationName: 'AGRA PUJYA INSTITUTE',
  logo: '/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg',
  motto: 'Our goal is good education, good character',
  tagline: 'Empowering Minds, Transforming Futures',
  subtagline: 'Education for All – Because Every Child Deserves a Chance.',
  establishedYear: 2022,
  bankDetails: {
    accountName: 'AGRA PUJYA INSTITUTE',
    bankName: 'State Bank of India (SBI)',
    accountNumber: '39847291048',
    ifscCode: 'SBIN0000091',
    branch: 'Hinjilicut Main Branch, Ganjam, Odisha – 761102',
    upiId: 'agrapujyainstitute@sbi',
    qrCodeImage: '',
    active: true,
  },
  location: {
    address: 'Hinjilicut, Ganjam, Odisha – 761102, India',
    city: 'Hinjilicut',
    district: 'Ganjam',
    state: 'Odisha',
    pincode: '761102',
    country: 'India',
    primaryPhone: '+91 8339888551',
    secondaryPhone: '+91 8339888552',
    email: 'agrapujyainstitute@gmail.com',
    whatsappNumber: '+918339888551',
    mapQuery: 'Hinjilicut, Ganjam, Odisha 761102',
  },
  founder: {
    name: 'PRAHALAD BEHERA',
    role: 'Founder & Leader',
    bio: 'AGRA PUJYA INSTITUTE was founded and is led by Prahalad Behera, driven by a deep commitment to social impact, quality education, and community development across southern Odisha. Driven by the belief that financial constraints should never halt educational aspiration, Prahalad has pioneered zero-fee learning opportunities for orphaned and underprivileged youth.',
    message: 'Welcome to Agra Pujya Institute. We started in 2022 right here in Hinjilicut with a single, uncompromising belief: every single child, no matter their financial circumstance or background, deserves quality education and dedicated mentorship. We are here to ensure that neither poverty nor personal loss ever stands in the way of a child reaching their fullest potential. Together with our passionate educators and community supporters, we are building pathways of dignity, self-reliance, and opportunity for every student who walks through our doors.',
    image: '/assets/images/founder_prahalad_official.png',
  },
  vision: 'We envision an inclusive society where every child, regardless of financial circumstances, has access to quality education and the opportunity to achieve their dreams.',
  mission: 'Our mission is to provide accessible academic support, mentorship and skill development opportunities to deserving students, especially orphaned children and those from economically disadvantaged families.',
  zeroFeePolicy: {
    orphanPolicy: 'Children who have lost their parents receive education and academic support completely free of cost. Our absolute zero-fee commitment ensures that orphaned children can continue their educational journey without financial pressure.',
    needyPolicy: 'No student should be denied education because of poverty. Children from families experiencing extreme financial hardship receive fully sponsored coaching and educational resources.',
  },
  sustainability: {
    statement: 'To sustain high academic standards, maintain modern learning spaces and compensate dedicated educators, the institute operates on a highly subsidized fee structure. Nominal charges from non-sponsored students are directly reinvested into educational development.',
    pillars: [
      {
        title: 'Infrastructure & Facilities',
        description: 'Maintaining safe, clean and interactive classroom environments equipped with proper ventilation and seating.',
      },
      {
        title: 'Faculty Honorarium',
        description: 'Supporting and recognizing the dedication of skilled tutors who devote extra time to student mentorship.',
      },
      {
        title: 'Learning Resources',
        description: 'Providing essential educational tools, whiteboards, study materials and ergonomic classroom furniture.',
      },
    ],
  },
  donationConfig: {
    gatewayActive: false,
    gatewayNotice: 'Official online payment gateway integration is currently in progress. Agra Pujya Institute operates with complete transparency and does not collect unauthorized online funds. To support a child’s education or contribute learning materials, please connect directly with our founder and administrative team.',
    bankAccountDetails: 'Official Trust Bank Account Details will be published upon regulatory verification. Please contact founder Prahalad Behera for authenticated sponsorship paperwork.',
    upiIdPlaceholder: 'Authentic organizational UPI handle pending verification.',
    officialPledgeInstructions: 'Supporters can submit a sponsorship pledge form or visit our Hinjilicut center in person to donate stationery, books, and study materials.',
  },
};

export const DEFAULT_PROGRAMS: EducationalProgram[] = [
  {
    id: 'prog-primary-secondary',
    title: 'Primary & Secondary Education',
    subtitle: 'Classes 1 to 10',
    level: 'School Level (Class 1–10)',
    medium: 'Odia Medium & English Medium',
    description: 'Comprehensive academic foundation and subject-wise coaching for foundational and secondary grade school students in Hinjilicut.',
    curriculumPoints: [
      'Comprehensive coaching across all core subjects (Mathematics, Science, English, MIL Odia, Social Studies)',
      'Odia Medium and English Medium bilingual academic support',
      'Fundamental concept clarity and individualized doubt-clearing sessions',
      'Regular weekly assessments, chapter tests, and personalized progress monitoring',
      'Strong academic foundation building for high school board exams',
    ],
    features: [
      'Dedicated subject mentors',
      'Zero-fee sponsorship for orphaned and needy students',
      'Interactive blackboard and workbook exercises',
    ],
    image: '/assets/images/zero_fee_students_1794191606094.jpg',
  },
  {
    id: 'prog-higher-secondary',
    title: 'Higher Secondary Education',
    subtitle: '+2 all streams (Arts, Commerce and Science)',
    level: 'Intermediate (+2 / Arts, Commerce & Science - CHSE)',
    medium: 'CHSE Odisha Syllabus',
    description: 'Rigorous subject-wise coaching aligned strictly with the Council of Higher Secondary Education (CHSE), Odisha curriculum.',
    curriculumPoints: [
      'Subject-wise specialized coaching for Science (Physics, Chemistry, Math, Biology), Arts, and Commerce streams',
      'Adherence to updated CHSE Odisha syllabus and textbook standards',
      'Strategic Board examination preparation and answer writing techniques',
      'In-depth previous question paper analysis and chapter-wise mock tests',
      'Special analytical problem-solving and numerical coaching sessions',
    ],
    features: [
      'CHSE Odisha targeted test series',
      'Comprehensive printed formula sheets and study notes',
      'Career counseling and college admission guidance',
    ],
    image: '/assets/images/hero_child_studying_1794191606058.jpg',
  },
  {
    id: 'prog-degree',
    title: 'Degree Level Education',
    subtitle: '+3 all streams (Arts, Commerce and Science)',
    level: 'Undergraduate (+3 / Arts, Commerce & Science)',
    medium: 'University Level Academics',
    description: 'Advanced collegiate mentoring and academic guidance for college students pursuing undergraduate degree programs across Odisha universities.',
    curriculumPoints: [
      'Undergraduate academic guidance across Arts, Science, and Commerce disciplines',
      'Honours and Elective subjects deep-dive and theoretical clarity',
      'Advanced conceptual learning with seminar discussions and presentations',
      'University-level semester examination preparation and research writing support',
      'Guidance for competitive exams and post-graduate university entrances',
    ],
    features: [
      'Semester exam question bank solutions',
      'Reference reading material access',
      'Peer study circles and mentorship',
    ],
    image: '/assets/images/founder_prahalad_portrait_1794191608078.jpg',
  },
  {
    id: 'prog-skills',
    title: 'Professional Skill Development',
    subtitle: 'Computer Fundamentals & Graphic Design',
    level: 'Vocational & Digital Skills',
    medium: 'Practical Hands-On Lab',
    description: 'Empowering local youth with digital literacy, practical software skills, and creative graphic design capabilities for modern career opportunities.',
    curriculumPoints: [
      'Computer Fundamentals: Hardware basics, operating systems, file management, and internet navigation',
      'Digital Literacy: Typing skills in English and Odia, email communication, internet safety, and productivity suites',
      'Essential Software Knowledge: Microsoft Office (Word, Excel, PowerPoint) and Google Workspace',
      'Graphic Design Fundamentals: Color theory, typography, digital layout, and visual composition',
      'Practical Image Editing: Industry-standard creative workflows and hands-on Adobe Photoshop training',
    ],
    features: [
      'Dedicated computer lab workstation for every learner',
      'Portfolio building and practical design projects',
      'Job-readiness and digital freelancing basics',
    ],
    image: '/assets/images/computer_lab_learning_1794191606995.jpg',
  },
];

export const DEFAULT_GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Foundational Reading Session',
    category: 'Classroom Activities',
    image: '/assets/images/hero_child_studying_1794191606058.jpg',
    caption: 'Students engaged in guided reading and textbook comprehension during afternoon tutorial hours.',
  },
  {
    id: 'gal-2',
    title: 'Zero-Fee Supported Students in Hinjilicut',
    category: 'Students Learning',
    image: '/assets/images/zero_fee_students_1794191606094.jpg',
    caption: 'Orphaned and economically disadvantaged students receiving study notebooks and coaching materials.',
  },
  {
    id: 'gal-3',
    title: 'Hands-on Computer Lab Training',
    category: 'Computer Education',
    image: '/assets/images/computer_lab_learning_1794191606995.jpg',
    caption: 'Local youth learning practical software skills and computer fundamentals in our digital center.',
  },
  {
    id: 'gal-4',
    title: 'Academic Guidance & Mentorship',
    category: 'Educational Events',
    image: '/assets/images/founder_prahalad_official.png',
    caption: 'Founder Prahalad Behera reviewing curriculum and academic resources at Agra Pujya Institute, Hinjilicut.',
  },
  {
    id: 'gal-5',
    title: 'Peer Learning & Group Discussion',
    category: 'Classroom Activities',
    image: '/assets/images/zero_fee_students_1794191606094.jpg',
    caption: 'High school students collaborating on mathematics and science problem sets.',
  },
  {
    id: 'gal-6',
    title: 'Digital Literacy & Design Workshop',
    category: 'Institute Facilities',
    image: '/assets/images/computer_lab_learning_1794191606995.jpg',
    caption: 'Practical training lab equipped to bridge the digital divide for semi-urban students.',
  },
];

export const DEFAULT_ANNOUNCEMENTS: Announcement[] = [
  {
    id: 'ann-1',
    title: 'Free Education Admissions Open (2026–27)',
    content: 'Applications are actively invited for orphaned children and students from economically underprivileged families in Hinjilicut and surrounding villages for 100% free coaching.',
    date: 'Academic Year 2026–2027',
    priority: 'urgent',
    active: true,
  },
  {
    id: 'ann-2',
    title: 'New Computer Fundamentals Batch Starting',
    content: 'A new batch for Computer Fundamentals and Graphic Design begins on the 1st of next month. Free workstations reserved for sponsored students.',
    date: 'Monthly Enrollment',
    priority: 'normal',
    active: true,
  },
];

// Clean initial data stores (real entries only)
const INITIAL_APPLICATIONS: AdmissionApplication[] = [];
const INITIAL_VOLUNTEERS: VolunteerApplication[] = [];
const INITIAL_MESSAGES: ContactMessage[] = [];

// Database helper functions
export const db = {
  // Site Content
  getSiteContent(): SiteContent {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SITE_CONTENT);
      if (!stored) {
        localStorage.setItem(STORAGE_KEYS.SITE_CONTENT, JSON.stringify(DEFAULT_SITE_CONTENT));
        return DEFAULT_SITE_CONTENT;
      }
      const parsed = JSON.parse(stored);
      return {
        ...DEFAULT_SITE_CONTENT,
        ...parsed,
        bankDetails: {
          ...DEFAULT_SITE_CONTENT.bankDetails,
          ...(parsed.bankDetails || {}),
        },
        logo: parsed.logo || DEFAULT_SITE_CONTENT.logo,
        motto: parsed.motto || DEFAULT_SITE_CONTENT.motto,
      };
    } catch {
      return DEFAULT_SITE_CONTENT;
    }
  },

  updateSiteContent(updates: Partial<SiteContent>): SiteContent {
    const current = this.getSiteContent();
    const merged = { ...current, ...updates };
    localStorage.setItem(STORAGE_KEYS.SITE_CONTENT, JSON.stringify(merged));
    return merged;
  },

  // Programs
  getPrograms(): EducationalProgram[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.PROGRAMS);
      if (!stored) {
        localStorage.setItem(STORAGE_KEYS.PROGRAMS, JSON.stringify(DEFAULT_PROGRAMS));
        return DEFAULT_PROGRAMS;
      }
      return JSON.parse(stored);
    } catch {
      return DEFAULT_PROGRAMS;
    }
  },

  updateProgram(program: EducationalProgram): void {
    const list = this.getPrograms();
    const idx = list.findIndex((p) => p.id === program.id);
    if (idx >= 0) {
      list[idx] = program;
    } else {
      list.push(program);
    }
    localStorage.setItem(STORAGE_KEYS.PROGRAMS, JSON.stringify(list));
  },

  // Gallery
  getGalleryItems(): GalleryItem[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.GALLERY);
      if (!stored) {
        localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(DEFAULT_GALLERY_ITEMS));
        return DEFAULT_GALLERY_ITEMS;
      }
      return JSON.parse(stored);
    } catch {
      return DEFAULT_GALLERY_ITEMS;
    }
  },

  addGalleryItem(item: Omit<GalleryItem, 'id'>): GalleryItem {
    const list = this.getGalleryItems();
    const newItem: GalleryItem = {
      ...item,
      id: `gal-${Date.now()}`,
    };
    list.unshift(newItem);
    localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(list));
    return newItem;
  },

  deleteGalleryItem(id: string): void {
    const list = this.getGalleryItems().filter((item) => item.id !== id);
    localStorage.setItem(STORAGE_KEYS.GALLERY, JSON.stringify(list));
  },

  // Announcements
  getAnnouncements(): Announcement[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ANNOUNCEMENTS);
      if (!stored) {
        localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(DEFAULT_ANNOUNCEMENTS));
        return DEFAULT_ANNOUNCEMENTS;
      }
      return JSON.parse(stored);
    } catch {
      return DEFAULT_ANNOUNCEMENTS;
    }
  },

  saveAnnouncements(list: Announcement[]): void {
    localStorage.setItem(STORAGE_KEYS.ANNOUNCEMENTS, JSON.stringify(list));
  },

  // Admission Applications
  getApplications(): AdmissionApplication[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.APPLICATIONS);
      if (!stored) {
        localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(INITIAL_APPLICATIONS));
        return INITIAL_APPLICATIONS;
      }
      return JSON.parse(stored);
    } catch {
      return INITIAL_APPLICATIONS;
    }
  },

  submitApplication(data: Omit<AdmissionApplication, 'id' | 'status' | 'createdAt'>): AdmissionApplication {
    const applications = this.getApplications();
    const nextSeq = applications.length + 1;
    const newId = `API-APP-2026-${String(nextSeq).padStart(3, '0')}`;
    const newApplication: AdmissionApplication = {
      ...data,
      id: newId,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };
    applications.unshift(newApplication);
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(applications));
    return newApplication;
  },

  updateApplicationStatus(id: string, status: AdmissionApplication['status'], notes?: string): void {
    const applications = this.getApplications();
    const target = applications.find((a) => a.id === id);
    if (target) {
      target.status = status;
      if (notes !== undefined) {
        target.notes = notes;
      }
      localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(applications));
    }
  },

  deleteApplication(id: string): void {
    const applications = this.getApplications().filter((a) => a.id !== id);
    localStorage.setItem(STORAGE_KEYS.APPLICATIONS, JSON.stringify(applications));
  },

  // Volunteers
  getVolunteers(): VolunteerApplication[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.VOLUNTEERS);
      if (!stored) {
        localStorage.setItem(STORAGE_KEYS.VOLUNTEERS, JSON.stringify(INITIAL_VOLUNTEERS));
        return INITIAL_VOLUNTEERS;
      }
      return JSON.parse(stored);
    } catch {
      return INITIAL_VOLUNTEERS;
    }
  },

  submitVolunteer(data: Omit<VolunteerApplication, 'id' | 'status' | 'createdAt'>): VolunteerApplication {
    const list = this.getVolunteers();
    const newId = `API-VOL-2026-${String(list.length + 1).padStart(3, '0')}`;
    const newVol: VolunteerApplication = {
      ...data,
      id: newId,
      status: 'New',
      createdAt: new Date().toISOString(),
    };
    list.unshift(newVol);
    localStorage.setItem(STORAGE_KEYS.VOLUNTEERS, JSON.stringify(list));
    return newVol;
  },

  updateVolunteerStatus(id: string, status: VolunteerApplication['status']): void {
    const list = this.getVolunteers();
    const target = list.find((v) => v.id === id);
    if (target) {
      target.status = status;
      localStorage.setItem(STORAGE_KEYS.VOLUNTEERS, JSON.stringify(list));
    }
  },

  // Contact Messages
  getContactMessages(): ContactMessage[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.MESSAGES);
      if (!stored) {
        localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(INITIAL_MESSAGES));
        return INITIAL_MESSAGES;
      }
      return JSON.parse(stored);
    } catch {
      return INITIAL_MESSAGES;
    }
  },

  submitContactMessage(data: Omit<ContactMessage, 'id' | 'read' | 'createdAt'>): ContactMessage {
    const list = this.getContactMessages();
    const newId = `API-MSG-${Date.now()}`;
    const newMsg: ContactMessage = {
      ...data,
      id: newId,
      read: false,
      createdAt: new Date().toISOString(),
    };
    list.unshift(newMsg);
    localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(list));
    return newMsg;
  },

  markContactMessageRead(id: string): void {
    const list = this.getContactMessages();
    const target = list.find((m) => m.id === id);
    if (target) {
      target.read = true;
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(list));
    }
  },

  // Export functions
  exportApplicationsAsCSV(): string {
    const apps = this.getApplications();
    const headers = ['ID', 'Student Name', 'Parent Name', 'Mobile', 'Email', 'Class', 'Medium', 'Course', 'Category', 'Status', 'Date', 'Address', 'Notes'];
    const rows = apps.map((a) => [
      a.id,
      `"${a.studentName.replace(/"/g, '""')}"`,
      `"${a.parentName.replace(/"/g, '""')}"`,
      `"${a.mobileNumber}"`,
      `"${a.email || ''}"`,
      `"${a.classLevel}"`,
      `"${a.medium}"`,
      `"${a.courseInterest}"`,
      `"${a.category}"`,
      `"${a.status}"`,
      `"${new Date(a.createdAt).toLocaleDateString()}"`,
      `"${a.address.replace(/"/g, '""')}"`,
      `"${(a.notes || '').replace(/"/g, '""')}"`,
    ]);
    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  },

  // Students & Fee Management
  getStudents(): StudentRecord[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.STUDENTS);
      if (!stored) {
        return [];
      }
      return JSON.parse(stored);
    } catch {
      return [];
    }
  },

  addStudent(studentData: Omit<StudentRecord, 'id' | 'createdAt' | 'paymentHistory'>): StudentRecord {
    const students = this.getStudents();
    const nextSeq = students.length + 1;
    const newId = `API-STU-${String(nextSeq).padStart(3, '0')}`;

    let computedStatus: StudentRecord['feeStatus'] = 'Paid';
    if (studentData.feeCategory.includes('Free')) {
      computedStatus = '100% Free';
    } else if (studentData.nextFeeDueDate) {
      const dueDate = new Date(studentData.nextFeeDueDate);
      const today = new Date();
      if (today > dueDate) {
        computedStatus = 'Overdue';
      } else {
        const diffDays = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 3600 * 24));
        computedStatus = diffDays <= 7 ? 'Due Soon' : 'Paid';
      }
    }

    const newStudent: StudentRecord = {
      ...studentData,
      id: newId,
      feeStatus: computedStatus,
      paymentHistory: [],
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    students.unshift(newStudent);
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    return newStudent;
  },

  updateStudent(id: string, updates: Partial<StudentRecord>): void {
    const students = this.getStudents();
    const idx = students.findIndex((s) => s.id === id);
    if (idx >= 0) {
      students[idx] = { ...students[idx], ...updates };
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    }
  },

  deleteStudent(id: string): void {
    const students = this.getStudents().filter((s) => s.id !== id);
    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
  },

  recordFeePayment(
    studentId: string,
    payment: Omit<FeePaymentRecord, 'id'>
  ): { student: StudentRecord; payment: FeePaymentRecord } | null {
    const students = this.getStudents();
    const student = students.find((s) => s.id === studentId);
    if (!student) return null;

    const receiptSeq = (student.paymentHistory?.length || 0) + 1;
    const receiptNum = payment.receiptNumber?.trim() || `RCP-${Date.now().toString().slice(-6)}-${receiptSeq}`;

    const newPayment: FeePaymentRecord = {
      ...payment,
      id: `fee-${Date.now()}`,
      receiptNumber: receiptNum,
    };

    student.paymentHistory = student.paymentHistory || [];
    student.paymentHistory.unshift(newPayment);
    student.lastPaymentDate = payment.paymentDate;
    student.lastPaymentMonth = payment.monthCovered;

    // Advance next due date by 1 month if paying student
    if (!student.feeCategory.includes('Free')) {
      if (student.nextFeeDueDate) {
        const d = new Date(student.nextFeeDueDate);
        d.setMonth(d.getMonth() + 1);
        student.nextFeeDueDate = d.toISOString().split('T')[0];
      } else {
        const nextMonth = new Date();
        nextMonth.setMonth(nextMonth.getMonth() + 1);
        student.nextFeeDueDate = nextMonth.toISOString().split('T')[0];
      }
      student.feeStatus = 'Paid';
    } else {
      student.feeStatus = '100% Free';
    }

    localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    return { student, payment: newPayment };
  },

  deleteFeePayment(studentId: string, paymentId: string): void {
    const students = this.getStudents();
    const student = students.find((s) => s.id === studentId);
    if (student && student.paymentHistory) {
      student.paymentHistory = student.paymentHistory.filter((p) => p.id !== paymentId);
      localStorage.setItem(STORAGE_KEYS.STUDENTS, JSON.stringify(students));
    }
  },

  exportAllDataAsJSON(): string {
    return JSON.stringify(
      {
        exportedAt: new Date().toISOString(),
        siteContent: this.getSiteContent(),
        programs: this.getPrograms(),
        students: this.getStudents(),
        applications: this.getApplications(),
        volunteers: this.getVolunteers(),
        messages: this.getContactMessages(),
        gallery: this.getGalleryItems(),
        announcements: this.getAnnouncements(),
      },
      null,
      2
    );
  },

  // Admin Credentials
  getAdminCredentials(): { email: string; passwordHash: string } {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ADMIN_CREDS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // fallback
    }
    return {
      email: 'agrapujyainstitute@gmail.com',
      passwordHash: 'API@Hinjilicut2026',
    };
  },

  updateAdminCredentials(email: string, newPassword?: string): void {
    const current = this.getAdminCredentials();
    const updated = {
      email: email.trim().toLowerCase(),
      passwordHash: newPassword && newPassword.trim() ? newPassword.trim() : current.passwordHash,
    };
    localStorage.setItem(STORAGE_KEYS.ADMIN_CREDS, JSON.stringify(updated));
  },

  validateAdmin(inputEmail: string, inputPass: string): boolean {
    const creds = this.getAdminCredentials();
    return (
      inputEmail.trim().toLowerCase() === creds.email.toLowerCase() &&
      inputPass.trim() === creds.passwordHash
    );
  },

  resetToDefaults(): void {
    localStorage.removeItem(STORAGE_KEYS.SITE_CONTENT);
    localStorage.removeItem(STORAGE_KEYS.PROGRAMS);
    localStorage.removeItem(STORAGE_KEYS.GALLERY);
    localStorage.removeItem(STORAGE_KEYS.ANNOUNCEMENTS);
    localStorage.removeItem(STORAGE_KEYS.APPLICATIONS);
    localStorage.removeItem(STORAGE_KEYS.STUDENTS);
    localStorage.removeItem(STORAGE_KEYS.VOLUNTEERS);
    localStorage.removeItem(STORAGE_KEYS.MESSAGES);
  },
};
