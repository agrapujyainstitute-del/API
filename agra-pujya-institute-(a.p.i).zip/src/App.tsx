import { useState, useEffect } from 'react';
import { db } from './services/db';
import { SiteContent, EducationalProgram, GalleryItem, Announcement, ApplicationCategory } from './types';
import NoticeBanner from './components/NoticeBanner';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import AboutFounder from './components/AboutFounder';
import VisionMission from './components/VisionMission';
import ZeroFeePolicy from './components/ZeroFeePolicy';
import Programs from './components/Programs';
import ImpactStories from './components/ImpactStories';
import Transparency from './components/Transparency';
import SupportDonate from './components/SupportDonate';
import Gallery from './components/Gallery';
import AdmissionForm from './components/AdmissionForm';
import VolunteerForm from './components/VolunteerForm';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import AdminDashboard from './components/AdminDashboard';

export default function App() {
  const [siteContent, setSiteContent] = useState<SiteContent>(db.getSiteContent());
  const [programs] = useState<EducationalProgram[]>(db.getPrograms());
  const [galleryItems] = useState<GalleryItem[]>(db.getGalleryItems());
  const [announcements, setAnnouncements] = useState<Announcement[]>(db.getAnnouncements());

  // Modal / Interaction states
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isVolunteerOpen, setIsVolunteerOpen] = useState(false);
  const [prefilledCategory, setPrefilledCategory] = useState<ApplicationCategory | undefined>(undefined);
  const [prefilledCourse, setPrefilledCourse] = useState<string | undefined>(undefined);

  // Smooth scroll handler helper
  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleApplyForFreeEducation = (category?: string) => {
    if (category) {
      setPrefilledCategory(category as ApplicationCategory);
    }
    scrollToSection('apply');
  };

  const handleProgramEnquire = (courseTitle: string) => {
    setPrefilledCourse(courseTitle);
    scrollToSection('apply');
  };

  const handleSupportCause = () => {
    scrollToSection('support');
  };

  const handleExploreMission = () => {
    scrollToSection('vision-mission');
  };

  const handleContactOpen = () => {
    scrollToSection('contact');
  };

  // Re-fetch data on updates
  const handleContentUpdated = (newContent: SiteContent) => {
    setSiteContent(newContent);
    setAnnouncements(db.getAnnouncements());
  };

  // Listen to keyboard shortcut for admin (Alt + A)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.key.toLowerCase() === 'a') {
        setIsAdminOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-[#FAF8F5] text-slate-800 flex flex-col selection:bg-amber-100 selection:text-amber-900">
      {/* 1. Announcement Notice Banner */}
      <NoticeBanner
        announcements={announcements}
        onApplyClick={() => handleApplyForFreeEducation('Free Education for Orphans')}
      />

      {/* 2. Top Bar Navigation (Strict 3-zone contract) */}
      <Navbar
        onOpenDonate={handleSupportCause}
        onOpenApply={() => scrollToSection('apply')}
        onOpenAdmin={() => setIsAdminOpen(true)}
      />

      {/* Main Content Flow */}
      <main className="flex-1">
        {/* 3. Hero Section */}
        <Hero
          onExploreMission={handleExploreMission}
          onSupportCause={handleSupportCause}
          onApplyFree={() => handleApplyForFreeEducation('Free Education for Orphans')}
        />

        {/* 4. About Our NGO & Founder */}
        <AboutFounder content={siteContent} />

        {/* 5. Vision & Mission */}
        <VisionMission content={siteContent} />

        {/* 6. Zero-Fee Education Policy (Centerpiece) */}
        <ZeroFeePolicy
          content={siteContent}
          onApplyFreeEducation={handleApplyForFreeEducation}
        />

        {/* 7. Educational Programs */}
        <Programs
          programs={programs}
          onEnquire={handleProgramEnquire}
        />

        {/* 8. Social Impact */}
        <ImpactStories />

        {/* 9. Transparency & Sustainability */}
        <Transparency content={siteContent} />

        {/* 10. Support Our Cause & Pledges */}
        <SupportDonate
          content={siteContent}
          onOpenVolunteer={() => setIsVolunteerOpen(true)}
          onOpenContact={handleContactOpen}
        />

        {/* 11. Visual Gallery - Stories of Hope */}
        <Gallery items={galleryItems} />

        {/* 12. Admission & Free Education Form */}
        <AdmissionForm
          initialCategory={prefilledCategory}
          initialCourse={prefilledCourse}
        />

        {/* 13. Contact Us with Maps & Phone Links */}
        <ContactSection content={siteContent} />
      </main>

      {/* 14. Footer */}
      <Footer
        content={siteContent}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenApply={() => scrollToSection('apply')}
        onOpenDonate={handleSupportCause}
      />

      {/* Volunteer Modal */}
      <VolunteerForm
        isOpen={isVolunteerOpen}
        onClose={() => setIsVolunteerOpen(false)}
      />

      {/* Secure Admin Dashboard Modal */}
      <AdminDashboard
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        onContentUpdated={handleContentUpdated}
      />
    </div>
  );
}
