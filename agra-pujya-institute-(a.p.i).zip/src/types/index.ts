export type MediumType = 'Odia' | 'English' | 'Both';

export type ApplicationCategory =
  | 'Free Education for Orphans'
  | 'Sponsored Education for Economically Needy Students'
  | 'General Admission';

export type ApplicationStatus =
  | 'Pending'
  | 'Under Review'
  | 'Approved for Free Education'
  | 'Enrolled'
  | 'Contacted'
  | 'Archived';

export type StudentFeeCategory =
  | 'Zero-Fee Orphan (100% Free)'
  | 'Sponsored Economically Needy (100% Free)'
  | 'Subsidized Regular (Paying)';

export type FeeStatus = '100% Free' | 'Paid' | 'Due Soon' | 'Overdue';

export interface FeePaymentRecord {
  id: string;
  paymentDate: string;
  monthCovered: string; // e.g. "November 2026"
  amountPaid: number;
  paymentMode: 'Cash' | 'UPI' | 'Bank Transfer';
  receiptNumber: string;
  recordedBy?: string;
  notes?: string;
}

export interface StudentRecord {
  id: string; // Roll / Admission ID e.g. API-STU-001
  studentName: string;
  parentName: string;
  mobileNumber: string;
  email?: string;
  address?: string;
  classLevel: string; // e.g. Class 10 / +2 1st Year Science / +3 Arts
  stream?: string; // Arts, Science, Commerce, Computer & Vocational, School
  medium: MediumType;
  joiningMonth: string; // e.g. "November 2026"
  joiningDate: string; // YYYY-MM-DD
  feeCategory: StudentFeeCategory;
  monthlyFee: number; // ₹0 for 100% Free, or ₹300, ₹500, etc.
  feeStatus: FeeStatus;
  lastPaymentDate?: string;
  lastPaymentMonth?: string;
  nextFeeDueDate?: string; // YYYY-MM-DD
  paymentHistory: FeePaymentRecord[];
  notes?: string;
  isActive: boolean;
  createdAt: string;
}

export interface AdmissionApplication {
  id: string;
  studentName: string;
  parentName: string;
  mobileNumber: string;
  email?: string;
  address: string;
  classLevel: string;
  medium: MediumType;
  courseInterest: string;
  category: ApplicationCategory;
  additionalInfo?: string;
  status: ApplicationStatus;
  createdAt: string;
  notes?: string;
}

export interface VolunteerApplication {
  id: string;
  fullName: string;
  contactNumber: string;
  email: string;
  skills: string;
  areaOfInterest: string;
  message: string;
  status: 'New' | 'Contacted' | 'Active' | 'Archived';
  createdAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface EducationalProgram {
  id: string;
  title: string;
  subtitle: string;
  level: string;
  medium: string;
  description: string;
  curriculumPoints: string[];
  features: string[];
  image: string;
}

export type GalleryCategory =
  | 'All'
  | 'Classroom Activities'
  | 'Students Learning'
  | 'Computer Education'
  | 'Educational Events'
  | 'Community Activities'
  | 'Institute Facilities';

export interface GalleryItem {
  id: string;
  title: string;
  category: Exclude<GalleryCategory, 'All'>;
  image: string;
  caption: string;
  date?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  priority: 'normal' | 'urgent';
  active: boolean;
}

export interface SupportCause {
  id: string;
  title: string;
  tagline: string;
  description: string;
  iconName: string;
}

export interface DonationConfig {
  gatewayActive: boolean;
  gatewayNotice: string;
  bankAccountDetails: string;
  upiIdPlaceholder: string;
  officialPledgeInstructions: string;
}

export interface BankDetails {
  accountName: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
  upiId: string;
  qrCodeImage?: string;
  active: boolean;
}

export interface SiteContent {
  organizationName: string;
  logo: string;
  motto: string;
  tagline: string;
  subtagline: string;
  establishedYear: number;
  bankDetails: BankDetails;
  location: {
    address: string;
    city: string;
    district: string;
    state: string;
    pincode: string;
    country: string;
    primaryPhone: string;
    secondaryPhone: string;
    email: string;
    whatsappNumber: string;
    mapQuery: string;
  };
  founder: {
    name: string;
    role: string;
    bio: string;
    message: string;
    image: string;
  };
  vision: string;
  mission: string;
  zeroFeePolicy: {
    orphanPolicy: string;
    needyPolicy: string;
  };
  sustainability: {
    statement: string;
    pillars: {
      title: string;
      description: string;
    }[];
  };
  donationConfig: DonationConfig;
}
