import { useState, useMemo } from 'react';
import {
  Users,
  UserPlus,
  Receipt,
  Search,
  Filter,
  Trash2,
  Calendar,
  Phone,
  ExternalLink,
  Printer,
  CheckCircle2,
  AlertCircle,
  Clock,
  Download,
  IndianRupee,
  X,
  CreditCard,
  Building2,
  ShieldCheck,
  Heart,
  ChevronRight,
  Send,
} from 'lucide-react';
import { StudentRecord, FeePaymentRecord, StudentFeeCategory, MediumType } from '../types';
import { db } from '../services/db';

interface StudentFeeManagerProps {
  onNotify: (message: string) => void;
  initialApplicantToAdmit?: {
    studentName: string;
    parentName: string;
    mobileNumber: string;
    classLevel: string;
    category: string;
    medium: MediumType;
  } | null;
  onClearInitialApplicant?: () => void;
}

export default function StudentFeeManager({
  onNotify,
  initialApplicantToAdmit,
  onClearInitialApplicant,
}: StudentFeeManagerProps) {
  const [students, setStudents] = useState<StudentRecord[]>(() => db.getStudents());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | '100% Free' | 'Paid' | 'Due Soon' | 'Overdue'>('All');
  const [classFilter, setClassFilter] = useState<string>('All');

  // Modal States
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);

  // Selected Student for payment/history
  const [activeStudent, setActiveStudent] = useState<StudentRecord | null>(null);
  const [activeReceipt, setActiveReceipt] = useState<FeePaymentRecord | null>(null);

  // Current month helper
  const currentMonthName = useMemo(() => {
    return new Date().toLocaleString('en-IN', { month: 'long', year: 'numeric' });
  }, []);

  const todayIso = useMemo(() => {
    return new Date().toISOString().split('T')[0];
  }, []);

  // Next month due date helper (5th of next month)
  const defaultNextDueDate = useMemo(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    d.setDate(5);
    return d.toISOString().split('T')[0];
  }, []);

  // Add Student Form State
  const [formData, setFormData] = useState({
    studentName: initialApplicantToAdmit?.studentName || '',
    parentName: initialApplicantToAdmit?.parentName || '',
    mobileNumber: initialApplicantToAdmit?.mobileNumber || '',
    email: '',
    address: 'Hinjilicut, Ganjam, Odisha',
    classLevel: initialApplicantToAdmit?.classLevel || '+2 1st Year Science',
    stream: 'Science',
    medium: (initialApplicantToAdmit?.medium || 'Odia') as MediumType,
    joiningMonth: currentMonthName,
    joiningDate: todayIso,
    feeCategory: (initialApplicantToAdmit?.category?.includes('Orphan')
      ? 'Zero-Fee Orphan (100% Free)'
      : initialApplicantToAdmit?.category?.includes('Needy')
      ? 'Sponsored Economically Needy (100% Free)'
      : 'Subsidized Regular (Paying)') as StudentFeeCategory,
    monthlyFee: initialApplicantToAdmit?.category?.includes('Free') ? 0 : 300,
    nextFeeDueDate: defaultNextDueDate,
    notes: '',
  });

  // Handle incoming applicant to admit
  if (initialApplicantToAdmit && !isAddModalOpen) {
    setIsAddModalOpen(true);
    if (onClearInitialApplicant) {
      onClearInitialApplicant();
    }
  }

  // Payment Form State
  const [paymentForm, setPaymentForm] = useState({
    monthCovered: currentMonthName,
    amountPaid: 300,
    paymentDate: todayIso,
    paymentMode: 'Cash' as FeePaymentRecord['paymentMode'],
    receiptNumber: '',
    notes: '',
  });

  const refreshStudents = () => {
    setStudents(db.getStudents());
  };

  // Metrics Calculations
  const stats = useMemo(() => {
    const total = students.length;
    const freeSponsored = students.filter((s) => s.feeCategory.includes('Free')).length;
    const payingStudents = students.filter((s) => !s.feeCategory.includes('Free')).length;

    let totalCollectedAllTime = 0;
    students.forEach((s) => {
      s.paymentHistory?.forEach((p) => {
        totalCollectedAllTime += Number(p.amountPaid || 0);
      });
    });

    const overdueCount = students.filter((s) => {
      if (s.feeCategory.includes('Free')) return false;
      if (!s.nextFeeDueDate) return false;
      return new Date(s.nextFeeDueDate) < new Date(todayIso);
    }).length;

    const dueSoonCount = students.filter((s) => {
      if (s.feeCategory.includes('Free')) return false;
      if (!s.nextFeeDueDate) return false;
      const due = new Date(s.nextFeeDueDate);
      const today = new Date(todayIso);
      const diff = Math.ceil((due.getTime() - today.getTime()) / (1000 * 3600 * 24));
      return diff >= 0 && diff <= 7;
    }).length;

    return {
      total,
      freeSponsored,
      payingStudents,
      totalCollectedAllTime,
      overdueCount,
      dueSoonCount,
    };
  }, [students, todayIso]);

  // Filtered Students
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      // Search
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        s.studentName.toLowerCase().includes(q) ||
        s.parentName.toLowerCase().includes(q) ||
        s.id.toLowerCase().includes(q) ||
        s.mobileNumber.toLowerCase().includes(q) ||
        s.classLevel.toLowerCase().includes(q);

      // Status
      let matchesStatus = true;
      if (statusFilter === '100% Free') {
        matchesStatus = s.feeCategory.includes('Free');
      } else if (statusFilter === 'Overdue') {
        matchesStatus = !s.feeCategory.includes('Free') && !!s.nextFeeDueDate && new Date(s.nextFeeDueDate) < new Date(todayIso);
      } else if (statusFilter === 'Due Soon') {
        if (s.feeCategory.includes('Free') || !s.nextFeeDueDate) {
          matchesStatus = false;
        } else {
          const due = new Date(s.nextFeeDueDate);
          const today = new Date(todayIso);
          const diff = Math.ceil((due.getTime() - today.getTime()) / (1000 * 3600 * 24));
          matchesStatus = diff >= 0 && diff <= 7;
        }
      } else if (statusFilter === 'Paid') {
        if (s.feeCategory.includes('Free')) {
          matchesStatus = false;
        } else if (!s.nextFeeDueDate) {
          matchesStatus = true;
        } else {
          matchesStatus = new Date(s.nextFeeDueDate) >= new Date(todayIso);
        }
      }

      // Class
      let matchesClass = true;
      if (classFilter !== 'All') {
        matchesClass = s.classLevel.includes(classFilter);
      }

      return matchesSearch && matchesStatus && matchesClass;
    });
  }, [students, searchQuery, statusFilter, classFilter, todayIso]);

  // Submit Add Student
  const handleCreateStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentName.trim() || !formData.parentName.trim() || !formData.mobileNumber.trim()) {
      alert('Please fill in Student Name, Guardian Name, and Contact Number.');
      return;
    }

    const created = db.addStudent({
      studentName: formData.studentName.trim(),
      parentName: formData.parentName.trim(),
      mobileNumber: formData.mobileNumber.trim(),
      email: formData.email.trim() || undefined,
      address: formData.address.trim() || undefined,
      classLevel: formData.classLevel,
      stream: formData.stream,
      medium: formData.medium,
      joiningMonth: formData.joiningMonth,
      joiningDate: formData.joiningDate,
      feeCategory: formData.feeCategory,
      monthlyFee: formData.feeCategory.includes('Free') ? 0 : Number(formData.monthlyFee) || 0,
      feeStatus: formData.feeCategory.includes('Free') ? '100% Free' : 'Paid',
      nextFeeDueDate: formData.feeCategory.includes('Free') ? undefined : formData.nextFeeDueDate,
      notes: formData.notes.trim() || undefined,
      isActive: true,
    });

    refreshStudents();
    setIsAddModalOpen(false);
    onNotify(`Student ${created.studentName} enrolled with Roll ID ${created.id}`);

    // Reset form
    setFormData({
      studentName: '',
      parentName: '',
      mobileNumber: '',
      email: '',
      address: 'Hinjilicut, Ganjam, Odisha',
      classLevel: '+2 1st Year Science',
      stream: 'Science',
      medium: 'Odia',
      joiningMonth: currentMonthName,
      joiningDate: todayIso,
      feeCategory: 'Subsidized Regular (Paying)',
      monthlyFee: 300,
      nextFeeDueDate: defaultNextDueDate,
      notes: '',
    });
  };

  // Open Payment Modal
  const openCollectFeeModal = (student: StudentRecord) => {
    setActiveStudent(student);
    setPaymentForm({
      monthCovered: student.nextFeeDueDate
        ? new Date(student.nextFeeDueDate).toLocaleString('en-IN', { month: 'long', year: 'numeric' })
        : currentMonthName,
      amountPaid: student.monthlyFee || 300,
      paymentDate: todayIso,
      paymentMode: 'Cash',
      receiptNumber: `RCP-${Date.now().toString().slice(-6)}`,
      notes: '',
    });
    setIsPaymentModalOpen(true);
  };

  // Submit Payment
  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStudent) return;

    const result = db.recordFeePayment(activeStudent.id, {
      monthCovered: paymentForm.monthCovered,
      amountPaid: Number(paymentForm.amountPaid) || 0,
      paymentDate: paymentForm.paymentDate,
      paymentMode: paymentForm.paymentMode,
      receiptNumber: paymentForm.receiptNumber,
      notes: paymentForm.notes.trim() || undefined,
      recordedBy: 'Founder Prahalad Behera',
    });

    if (result) {
      refreshStudents();
      setIsPaymentModalOpen(false);
      setActiveReceipt(result.payment);
      setIsReceiptModalOpen(true);
      onNotify(`Fee ₹${paymentForm.amountPaid} recorded for ${activeStudent.studentName}!`);
    }
  };

  // Delete Student
  const handleDeleteStudent = (student: StudentRecord) => {
    if (confirm(`Are you sure you want to delete student "${student.studentName}" (${student.id}) and all records? This cannot be undone.`)) {
      db.deleteStudent(student.id);
      refreshStudents();
      onNotify(`Student ${student.studentName} removed from records.`);
    }
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = [
      'Roll_ID',
      'Student_Name',
      'Guardian_Name',
      'Mobile',
      'Class_Course',
      'Stream',
      'Joining_Month',
      'Joining_Date',
      'Fee_Category',
      'Monthly_Fee_INR',
      'Last_Paid_Month',
      'Next_Due_Date',
      'Fee_Status',
    ];

    const rows = students.map((s) => [
      `"${s.id}"`,
      `"${s.studentName}"`,
      `"${s.parentName}"`,
      `"${s.mobileNumber}"`,
      `"${s.classLevel}"`,
      `"${s.stream || ''}"`,
      `"${s.joiningMonth}"`,
      `"${s.joiningDate}"`,
      `"${s.feeCategory}"`,
      s.monthlyFee,
      `"${s.lastPaymentMonth || 'None'}"`,
      `"${s.nextFeeDueDate || 'N/A'}"`,
      `"${s.feeStatus}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `agra_pujya_students_roster_${todayIso}.csv`;
    link.click();
    onNotify('Student roster exported as CSV file.');
  };

  // WhatsApp Message Helper
  const getWhatsAppFeeReminderUrl = (student: StudentRecord) => {
    const cleanPhone = student.mobileNumber.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `Namaskar ${student.parentName} ji,\n\nThis is an official intimation from Agra Pujya Institute, Hinjilicut regarding ${student.studentName} (${student.id}).\n\nCourse: ${student.classLevel}\nMonthly Subsidized Fee: ₹${student.monthlyFee}\nNext Fee Due Date: ${student.nextFeeDueDate || 'Upcoming'}\n\nPlease contact Founder Prahalad Behera (+91 8339888551) or visit our center to clear the monthly educational honorarium. Thank you for partnering with us.`
    );
    return `https://wa.me/${cleanPhone}?text=${text}`;
  };

  const getWhatsAppReceiptUrl = (student: StudentRecord, receipt: FeePaymentRecord) => {
    const cleanPhone = student.mobileNumber.replace(/[^0-9]/g, '');
    const text = encodeURIComponent(
      `*AGRA PUJYA INSTITUTE · OFFICIAL FEE RECEIPT*\n` +
      `------------------------------------\n` +
      `Receipt No: ${receipt.receiptNumber}\n` +
      `Date: ${receipt.paymentDate}\n` +
      `Student: ${student.studentName} (${student.id})\n` +
      `Guardian: ${student.parentName}\n` +
      `Class: ${student.classLevel}\n` +
      `Month Covered: ${receipt.monthCovered}\n` +
      `Amount Paid: ₹${receipt.amountPaid} (${receipt.paymentMode})\n` +
      `Next Due Date: ${student.nextFeeDueDate || 'N/A'}\n` +
      `------------------------------------\n` +
      `Thank you for supporting your child's education at Agra Pujya Institute, Hinjilicut.\nFounder: Prahalad Behera`
    );
    return `https://wa.me/${cleanPhone}?text=${text}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-700 mb-1">
            <Users className="w-4 h-4 text-amber-500" />
            <span>Student Academic & Fee Management Software</span>
          </div>
          <h3 className="font-serif text-2xl font-bold text-slate-900">
            Student Register &amp; Monthly Fee Records
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage enrolled students, joining months, zero-fee orphan exemptions, fee collections, and next due dates.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-slate-700 text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Download CSV Roster"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 bg-[#0A192F] hover:bg-[#122B4F] text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
          >
            <UserPlus className="w-4 h-4 text-amber-400" />
            <span>+ Admit / Add Student</span>
          </button>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5">
          <span className="text-[11px] font-semibold text-slate-500 uppercase block">Total Students</span>
          <span className="font-serif font-bold text-2xl text-slate-900">{stats.total}</span>
          <span className="text-[10px] text-slate-400 block mt-0.5">Active Academic Roster</span>
        </div>

        <div className="bg-emerald-50/60 border border-emerald-200 rounded-xl p-3.5">
          <span className="text-[11px] font-bold text-emerald-800 uppercase block flex items-center gap-1">
            <Heart className="w-3 h-3 text-rose-500" /> 100% Free Education
          </span>
          <span className="font-serif font-bold text-2xl text-emerald-900">{stats.freeSponsored}</span>
          <span className="text-[10px] text-emerald-700 font-semibold block mt-0.5">Orphans &amp; Needy (₹0 Fee)</span>
        </div>

        <div className="bg-blue-50/60 border border-blue-200 rounded-xl p-3.5">
          <span className="text-[11px] font-bold text-blue-800 uppercase block">Total Fees Collected</span>
          <span className="font-serif font-bold text-2xl text-blue-900">₹{stats.totalCollectedAllTime}</span>
          <span className="text-[10px] text-blue-700 block mt-0.5">Subsidized Reinvestments</span>
        </div>

        <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-3.5">
          <span className="text-[11px] font-bold text-amber-800 uppercase block flex items-center gap-1">
            <Clock className="w-3 h-3 text-amber-600" /> Due / Overdue Accounts
          </span>
          <span className="font-serif font-bold text-2xl text-amber-900">
            {stats.overdueCount + stats.dueSoonCount}
          </span>
          <span className="text-[10px] text-amber-700 block mt-0.5">
            {stats.overdueCount} Overdue · {stats.dueSoonCount} Due Soon
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-stone-200 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex-1 min-w-[220px] relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search by student name, roll number, phone, or class..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs border border-stone-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          {/* Status Filter */}
          <div className="flex items-center gap-1 bg-stone-100 p-0.5 rounded-lg">
            {(['All', '100% Free', 'Paid', 'Due Soon', 'Overdue'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors cursor-pointer ${
                  statusFilter === st
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          {/* Class Filter */}
          <select
            value={classFilter}
            onChange={(e) => setClassFilter(e.target.value)}
            className="px-2.5 py-1.5 bg-stone-100 border border-stone-200 rounded-lg text-slate-700 text-xs font-semibold focus:outline-none cursor-pointer"
          >
            <option value="All">All Classes</option>
            <option value="Primary">Primary (Class 1-5)</option>
            <option value="Class 10">Class 10 (Secondary)</option>
            <option value="+2">+2 Streams (CHSE)</option>
            <option value="+3">+3 Degree Level</option>
            <option value="Computer">Computer &amp; Vocational</option>
          </select>
        </div>
      </div>

      {/* Students Table */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-stone-50 text-slate-700 border-b border-stone-200 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4 font-bold">Roll / Student ID</th>
                <th className="py-3 px-4 font-bold">Student &amp; Guardian</th>
                <th className="py-3 px-4 font-bold">Class &amp; Stream</th>
                <th className="py-3 px-4 font-bold">Joining Month</th>
                <th className="py-3 px-4 font-bold">Fee Category</th>
                <th className="py-3 px-4 font-bold">Monthly Fee</th>
                <th className="py-3 px-4 font-bold">Next Fee Due</th>
                <th className="py-3 px-4 font-bold">Fee Status</th>
                <th className="py-3 px-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                    <p className="font-semibold text-slate-600 text-sm">No student records found.</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      {students.length === 0
                        ? 'Your student database is clean. Click "+ Admit / Add Student" to register your first student or admit applicants from the Admissions tab.'
                        : 'No students match the selected filter criteria.'}
                    </p>
                  </td>
                </tr>
              ) : (
                filteredStudents.map((st) => {
                  const isFree = st.feeCategory.includes('Free');
                  const isOverdue = !isFree && !!st.nextFeeDueDate && new Date(st.nextFeeDueDate) < new Date(todayIso);

                  return (
                    <tr key={st.id} className="hover:bg-blue-50/40 transition-colors">
                      {/* ID */}
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 whitespace-nowrap">
                        {st.id}
                      </td>

                      {/* Name & Guardian */}
                      <td className="py-3 px-4">
                        <p className="font-bold text-slate-900 text-xs sm:text-sm">{st.studentName}</p>
                        <p className="text-[11px] text-slate-500">Guardian: {st.parentName}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-[10px] text-slate-600">{st.mobileNumber}</span>
                          <a
                            href={getWhatsAppFeeReminderUrl(st)}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[10px] text-emerald-600 font-semibold hover:underline inline-flex items-center gap-0.5"
                            title="Chat or send reminder on WhatsApp"
                          >
                            <Send className="w-2.5 h-2.5" /> WhatsApp
                          </a>
                        </div>
                      </td>

                      {/* Class */}
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-800 block">{st.classLevel}</span>
                        <span className="text-[10px] text-slate-400 block">{st.medium} Medium</span>
                      </td>

                      {/* Joining Month */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-medium text-slate-800 block">{st.joiningMonth}</span>
                        <span className="text-[10px] text-slate-400 block">{st.joiningDate}</span>
                      </td>

                      {/* Fee Category */}
                      <td className="py-3 px-4">
                        {isFree ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                            <Heart className="w-2.5 h-2.5 text-rose-500" />
                            <span>100% Free Sponsor</span>
                          </span>
                        ) : (
                          <span className="inline-block px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-semibold">
                            Subsidized Paying
                          </span>
                        )}
                      </td>

                      {/* Monthly Fee */}
                      <td className="py-3 px-4 font-mono font-bold">
                        {isFree ? (
                          <span className="text-emerald-700">₹0 (Free)</span>
                        ) : (
                          <span className="text-slate-900">₹{st.monthlyFee} / mo</span>
                        )}
                      </td>

                      {/* Next Fee Due */}
                      <td className="py-3 px-4 whitespace-nowrap font-mono text-[11px]">
                        {isFree ? (
                          <span className="text-slate-400 italic">Exempt</span>
                        ) : st.nextFeeDueDate ? (
                          <span className={isOverdue ? 'text-rose-600 font-bold' : 'text-slate-700 font-medium'}>
                            {st.nextFeeDueDate}
                          </span>
                        ) : (
                          <span className="text-slate-400">Not Set</span>
                        )}
                      </td>

                      {/* Status Badge */}
                      <td className="py-3 px-4 whitespace-nowrap">
                        {isFree ? (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                            Exempt / 100% Free
                          </span>
                        ) : isOverdue ? (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                            Overdue
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-emerald-100 text-emerald-800">
                            Paid Up
                          </span>
                        )}
                      </td>

                      {/* Action Buttons */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {!isFree && (
                            <button
                              onClick={() => openCollectFeeModal(st)}
                              className="px-2.5 py-1 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer flex items-center gap-1"
                              title="Record Monthly Fee Payment"
                            >
                              <Receipt className="w-3.5 h-3.5" />
                              <span>Collect Fee</span>
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setActiveStudent(st);
                              setIsHistoryModalOpen(true);
                            }}
                            className="px-2 py-1 text-xs font-semibold text-slate-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
                            title="View Payment Receipts & History"
                          >
                            <span>Receipts ({st.paymentHistory?.length || 0})</span>
                          </button>

                          <button
                            onClick={() => handleDeleteStudent(st)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                            title="Delete Student Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: ADD / ADMIT STUDENT */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 p-6 sm:p-8 relative">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-stone-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-700 mb-2">
              <UserPlus className="w-4 h-4 text-amber-500" />
              <span>Student Admission &amp; Enrollment</span>
            </div>
            <h3 className="font-serif text-2xl font-bold text-slate-900 mb-1">
              Admit New Student to Agra Pujya Institute
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              Enter student credentials, fee category, joining month, and next fee due schedule.
            </p>

            <form onSubmit={handleCreateStudent} className="space-y-4 text-xs">
              {/* Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Student Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Subhasree Nayak"
                    value={formData.studentName}
                    onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Guardian / Parent Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Late Ramesh Nayak (Mother: Kuni Nayak)"
                    value={formData.parentName}
                    onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              {/* Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">WhatsApp / Contact Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. +91 8339888551"
                    value={formData.mobileNumber}
                    onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Email Address (Optional)</label>
                  <input
                    type="email"
                    placeholder="student@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              {/* Class & Medium */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 mb-1">Course / Educational Level *</label>
                  <select
                    value={formData.classLevel}
                    onChange={(e) => setFormData({ ...formData, classLevel: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    <option value="+2 1st Year Science">+2 1st Year (Science Stream - CHSE)</option>
                    <option value="+2 2nd Year Science">+2 2nd Year (Science Stream - CHSE)</option>
                    <option value="+2 1st Year Arts">+2 1st Year (Arts Stream - CHSE)</option>
                    <option value="+2 2nd Year Arts">+2 2nd Year (Arts Stream - CHSE)</option>
                    <option value="+2 1st Year Commerce">+2 1st Year (Commerce Stream - CHSE)</option>
                    <option value="+2 2nd Year Commerce">+2 2nd Year (Commerce Stream - CHSE)</option>
                    <option value="+3 Degree Arts">+3 Degree Level (Arts / Undergraduate)</option>
                    <option value="+3 Degree Science">+3 Degree Level (Science / Undergraduate)</option>
                    <option value="+3 Degree Commerce">+3 Degree Level (Commerce / Undergraduate)</option>
                    <option value="Class 10 (Secondary)">Class 10 (High School Board Exam)</option>
                    <option value="Class 9">Class 9 (Foundational Secondary)</option>
                    <option value="Middle School (Class 6-8)">Middle School (Class 6–8)</option>
                    <option value="Primary School (Class 1-5)">Primary School (Class 1–5)</option>
                    <option value="Computer & Graphic Design">Computer Fundamentals &amp; Graphic Design</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Medium</label>
                  <select
                    value={formData.medium}
                    onChange={(e) => setFormData({ ...formData, medium: e.target.value as MediumType })}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    <option value="Odia">Odia Medium</option>
                    <option value="English">English Medium</option>
                    <option value="Both">Bilingual / Both</option>
                  </select>
                </div>
              </div>

              {/* Joining Month & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Joining Month (Month Enrolled) *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. November 2026"
                    value={formData.joiningMonth}
                    onChange={(e) => setFormData({ ...formData, joiningMonth: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Enrollment Date *</label>
                  <input
                    type="date"
                    required
                    value={formData.joiningDate}
                    onChange={(e) => setFormData({ ...formData, joiningDate: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
              </div>

              {/* Fee Category */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Fee Category *</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'Zero-Fee Orphan (100% Free)', label: '100% Free (Orphan)', sub: 'Zero fee tuition & books' },
                    { id: 'Sponsored Economically Needy (100% Free)', label: '100% Free (Needy)', sub: 'Hardship sponsor' },
                    { id: 'Subsidized Regular (Paying)', label: 'Subsidized Paying', sub: 'Nominal fee' },
                  ].map((cat) => (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => {
                        const isF = cat.id.includes('Free');
                        setFormData({
                          ...formData,
                          feeCategory: cat.id as StudentFeeCategory,
                          monthlyFee: isF ? 0 : 300,
                        });
                      }}
                      className={`p-2.5 rounded-xl border text-left cursor-pointer transition-colors ${
                        formData.feeCategory === cat.id
                          ? 'border-blue-600 bg-blue-50/70 ring-1 ring-blue-600'
                          : 'border-stone-200 hover:bg-stone-50'
                      }`}
                    >
                      <span className="font-bold block text-slate-900">{cat.label}</span>
                      <span className="text-[10px] text-slate-500 block">{cat.sub}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Monthly Fee & Next Due Date (Only for Paying Students) */}
              {!formData.feeCategory.includes('Free') && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-stone-50 rounded-xl border border-stone-200">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Monthly Subsidized Fee (₹) *</label>
                    <input
                      type="number"
                      required
                      min={50}
                      step={50}
                      value={formData.monthlyFee}
                      onChange={(e) => setFormData({ ...formData, monthlyFee: Number(e.target.value) })}
                      className="w-full px-3 py-2 border rounded-xl font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Next Fee Due Date *</label>
                    <input
                      type="date"
                      required
                      value={formData.nextFeeDueDate}
                      onChange={(e) => setFormData({ ...formData, nextFeeDueDate: e.target.value })}
                      className="w-full px-3 py-2 border rounded-xl font-mono"
                    />
                  </div>
                </div>
              )}

              {/* Notes */}
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Administrative Notes (Optional)</label>
                <textarea
                  rows={2}
                  placeholder="Mention academic background, subjects, or special mentorship requirements..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-stone-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0A192F] hover:bg-[#122B4F] text-white font-bold rounded-xl shadow-sm flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Confirm Student Admission</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: RECORD FEE PAYMENT */}
      {isPaymentModalOpen && activeStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-200 p-6 sm:p-8 relative">
            <button
              onClick={() => setIsPaymentModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-stone-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700 mb-2">
              <Receipt className="w-4 h-4 text-emerald-600" />
              <span>Collect Monthly Educational Honorarium</span>
            </div>
            <h3 className="font-serif text-2xl font-bold text-slate-900 mb-1">
              Record Fee Payment
            </h3>

            {/* Student Info Box */}
            <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl my-4 text-xs">
              <div className="flex justify-between font-bold text-slate-900 text-sm">
                <span>{activeStudent.studentName}</span>
                <span className="font-mono text-blue-700">{activeStudent.id}</span>
              </div>
              <p className="text-slate-500 mt-0.5">{activeStudent.classLevel} · Guardian: {activeStudent.parentName}</p>
              <p className="text-slate-600 font-semibold mt-1">Monthly Rate: ₹{activeStudent.monthlyFee}</p>
            </div>

            <form onSubmit={handleSubmitPayment} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Month Covered *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. November 2026"
                    value={paymentForm.monthCovered}
                    onChange={(e) => setPaymentForm({ ...paymentForm, monthCovered: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Amount Paid (₹) *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={paymentForm.amountPaid}
                    onChange={(e) => setPaymentForm({ ...paymentForm, amountPaid: Number(e.target.value) })}
                    className="w-full px-3 py-2 border rounded-xl font-mono font-bold text-slate-900 text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Payment Date *</label>
                  <input
                    type="date"
                    required
                    value={paymentForm.paymentDate}
                    onChange={(e) => setPaymentForm({ ...paymentForm, paymentDate: e.target.value })}
                    className="w-full px-3 py-2 border rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Payment Mode *</label>
                  <select
                    value={paymentForm.paymentMode}
                    onChange={(e) => setPaymentForm({ ...paymentForm, paymentMode: e.target.value as any })}
                    className="w-full px-3 py-2 border rounded-xl bg-white"
                  >
                    <option value="Cash">Cash at Center</option>
                    <option value="UPI">UPI / QR Code</option>
                    <option value="Bank Transfer">Bank Transfer / NEFT</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Receipt Number</label>
                <input
                  type="text"
                  value={paymentForm.receiptNumber}
                  onChange={(e) => setPaymentForm({ ...paymentForm, receiptNumber: e.target.value })}
                  placeholder="Auto-generated if left empty"
                  className="w-full px-3 py-2 border rounded-xl font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Remarks / Note (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. Paid in full at Hinjilicut center"
                  value={paymentForm.notes}
                  onChange={(e) => setPaymentForm({ ...paymentForm, notes: e.target.value })}
                  className="w-full px-3 py-2 border rounded-xl"
                />
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
                <strong>Next Due Auto-Update:</strong> Saving this payment will automatically advance the student&apos;s Next Fee Due Date by 1 month and generate a print-ready receipt slip.
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-stone-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-sm flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Save Payment &amp; Generate Slip</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: PAYMENT RECEIPTS HISTORY */}
      {isHistoryModalOpen && activeStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-xl w-full max-h-[85vh] overflow-y-auto shadow-2xl border border-stone-200 p-6 sm:p-8 relative">
            <button
              onClick={() => setIsHistoryModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-stone-100"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-700 mb-1">
              <Receipt className="w-4 h-4" />
              <span>Payment Receipts History</span>
            </div>
            <h3 className="font-serif text-2xl font-bold text-slate-900 mb-1">
              {activeStudent.studentName}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              ID: {activeStudent.id} · Class: {activeStudent.classLevel} · Monthly Rate: ₹{activeStudent.monthlyFee}
            </p>

            <div className="space-y-3">
              {!activeStudent.paymentHistory || activeStudent.paymentHistory.length === 0 ? (
                <div className="py-8 text-center text-slate-400 bg-stone-50 rounded-xl border border-stone-200">
                  <Receipt className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-semibold text-slate-600 text-xs">No payment receipts recorded yet.</p>
                  {!activeStudent.feeCategory.includes('Free') && (
                    <button
                      onClick={() => {
                        setIsHistoryModalOpen(false);
                        openCollectFeeModal(activeStudent);
                      }}
                      className="mt-3 px-3 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded-lg inline-flex items-center gap-1"
                    >
                      <Receipt className="w-3 h-3" /> Record First Payment
                    </button>
                  )}
                </div>
              ) : (
                activeStudent.paymentHistory.map((rcp) => (
                  <div
                    key={rcp.id}
                    className="p-3.5 bg-stone-50 border border-stone-200 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-900">{rcp.receiptNumber}</span>
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                          ₹{rcp.amountPaid}
                        </span>
                      </div>
                      <p className="text-slate-600 font-semibold mt-0.5">Month: {rcp.monthCovered}</p>
                      <p className="text-[11px] text-slate-400">Date: {rcp.paymentDate} · Mode: {rcp.paymentMode}</p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          setActiveReceipt(rcp);
                          setIsReceiptModalOpen(true);
                        }}
                        className="px-2.5 py-1.5 bg-white border border-stone-300 hover:bg-stone-100 text-slate-700 font-semibold rounded-lg flex items-center gap-1 cursor-pointer"
                        title="View / Print Receipt Slip"
                      >
                        <Printer className="w-3.5 h-3.5 text-blue-700" />
                        <span>Print</span>
                      </button>

                      <a
                        href={getWhatsAppReceiptUrl(activeStudent, rcp)}
                        target="_blank"
                        rel="noreferrer"
                        className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                        title="Send Receipt Slip on WhatsApp"
                      >
                        <Send className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: FORMAL PRINTABLE FEE RECEIPT SLIP */}
      {isReceiptModalOpen && activeStudent && activeReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-stone-300 p-6 sm:p-8 relative">
            <button
              onClick={() => setIsReceiptModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-stone-100 print:hidden"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Print Container */}
            <div id="printableReceiptArea" className="space-y-4">
              {/* Slip Header */}
              <div className="text-center pb-4 border-b-2 border-slate-900">
                <div className="h-14 w-auto mx-auto mb-2 flex items-center justify-center">
                  <img
                    src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
                    alt="Agra Pujya Institute Emblem"
                    className="h-14 w-auto object-contain"
                  />
                </div>
                <h4 className="font-serif font-bold text-xl text-slate-900 uppercase tracking-tight">
                  AGRA PUJYA INSTITUTE
                </h4>
                <p className="text-[11px] font-serif italic text-amber-700">
                  &ldquo;Our goal is good education, good character&rdquo;
                </p>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Hinjilicut, Ganjam, Odisha – 761102 · Founder &amp; Leader: Prahalad Behera
                </p>
                <div className="mt-2 inline-block px-3 py-1 bg-slate-900 text-white rounded text-[10px] font-bold tracking-widest uppercase">
                  Official Educational Fee Receipt
                </div>
              </div>

              {/* Slip Details Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs py-2 border-b border-stone-200">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Receipt Number</span>
                  <span className="font-mono font-bold text-slate-900">{activeReceipt.receiptNumber}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Receipt Date</span>
                  <span className="font-mono text-slate-800">{activeReceipt.paymentDate}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Student Name</span>
                  <span className="font-bold text-slate-900 text-sm">{activeStudent.studentName}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Roll / Student ID</span>
                  <span className="font-mono font-bold text-blue-700">{activeStudent.id}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Guardian Name</span>
                  <span className="text-slate-800">{activeStudent.parentName}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 uppercase block font-semibold">Class / Stream</span>
                  <span className="text-slate-800 font-medium">{activeStudent.classLevel}</span>
                </div>
              </div>

              {/* Amount Box */}
              <div className="bg-stone-50 border border-stone-200 rounded-xl p-3 flex justify-between items-center text-xs">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase block">Fee Month Covered</span>
                  <span className="font-bold text-slate-900 text-sm">{activeReceipt.monthCovered}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 uppercase block">Amount Received</span>
                  <span className="font-mono font-bold text-emerald-700 text-lg">₹{activeReceipt.amountPaid}</span>
                  <span className="text-[10px] text-slate-400 block font-medium">({activeReceipt.paymentMode})</span>
                </div>
              </div>

              {/* Next Due & Signature */}
              <div className="pt-2 flex justify-between items-end text-xs text-slate-600">
                <div>
                  <span className="text-[10px] text-slate-400 block font-semibold">Next Fee Due Schedule:</span>
                  <span className="font-mono font-bold text-slate-900">{activeStudent.nextFeeDueDate || 'Paid Up'}</span>
                </div>
                <div className="text-right">
                  <div className="h-8 flex items-end justify-end">
                    <span className="font-serif italic text-blue-900 font-bold text-xs">Prahalad Behera</span>
                  </div>
                  <span className="text-[10px] text-slate-500 uppercase block font-semibold border-t border-slate-300 pt-0.5">
                    Authorized Signatory
                  </span>
                </div>
              </div>
            </div>

            {/* Print & Action Buttons */}
            <div className="flex items-center justify-between gap-3 pt-6 border-t border-stone-200 print:hidden text-xs">
              <a
                href={getWhatsAppReceiptUrl(activeStudent, activeReceipt)}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center gap-1.5 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send on WhatsApp</span>
              </a>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsReceiptModalOpen(false)}
                  className="px-3.5 py-2 text-slate-600 hover:bg-stone-100 rounded-xl"
                >
                  Close
                </button>
                <button
                  onClick={() => window.print()}
                  className="px-5 py-2 bg-[#0A192F] hover:bg-[#122B4F] text-white font-bold rounded-xl flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-400" />
                  <span>Print Slip</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
