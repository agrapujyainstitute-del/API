import { Building, Award, BookCheck, ShieldAlert } from 'lucide-react';
import { SiteContent } from '../types';

interface TransparencyProps {
  content: SiteContent;
}

export default function Transparency({ content }: TransparencyProps) {
  const { sustainability } = content;

  const pillarIcons = [Building, Award, BookCheck];

  return (
    <section className="py-20 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="text-xs font-semibold tracking-widest uppercase text-blue-700 block mb-2">
            Organizational Ethics & Sustainability
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 tracking-tight">
            Every Contribution Supports Education.
          </h2>
          <div className="w-14 h-1 bg-amber-500 mx-auto mt-4 mb-6 rounded-full" />
          <p className="text-slate-700 text-base sm:text-lg leading-relaxed font-serif italic max-w-2xl mx-auto">
            &ldquo;{sustainability.statement}&rdquo;
          </p>
        </div>

        {/* 3 Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {sustainability.pillars.map((pillar, idx) => {
            const Icon = pillarIcons[idx] || Building;
            return (
              <div
                key={pillar.title}
                className="bg-[#FAF8F5] rounded-2xl p-7 border border-stone-200 flex flex-col justify-between hover:border-slate-300 transition-colors"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-5 border border-blue-100">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block mb-1">
                    Reinvestment Priority 0{idx + 1}
                  </span>
                  <h3 className="text-xl font-serif font-bold text-slate-900 mb-3">
                    {pillar.title}
                  </h3>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-stone-200 text-[11px] text-slate-500 font-medium">
                  Direct educational reinvestment · 0% commercial diversion
                </div>
              </div>
            );
          })}
        </div>

        {/* Responsible Transparency Disclaimer */}
        <div className="max-w-3xl mx-auto p-5 rounded-xl bg-stone-50 border border-stone-200 text-xs text-slate-600 flex items-start gap-3">
          <ShieldAlert className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Honest Disclosure:</strong> Agra Pujya Institute is a grassroots educational community initiative
            serving Hinjilicut students. We uphold strict moral stewardship of all funds and classroom donations,
            allocating all resources strictly toward teachers, books, and child learning spaces.
          </p>
        </div>
      </div>
    </section>
  );
}
