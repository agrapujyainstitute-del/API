import { useState } from 'react';
import { MapPin, Phone, Mail, MessageSquare, Send, CheckCircle2, Navigation, MessageCircle } from 'lucide-react';
import { SiteContent } from '../types';
import { db } from '../services/db';
import { sendEmailNotification, ADMIN_EMAIL } from '../services/emailService';

interface ContactSectionProps {
  content: SiteContent;
}

export default function ContactSection({ content }: ContactSectionProps) {
  const { location, founder, organizationName } = content;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!formData.name.trim() || !formData.phone.trim() || !formData.message.trim()) {
      setErrorMessage('Please provide your name, phone number, and enquiry message.');
      return;
    }

    setIsSubmitting(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      db.submitContactMessage({
        name: formData.name.trim(),
        email: formData.email.trim(),
        phone: formData.phone.trim(),
        subject: formData.subject.trim() || 'General Enquiry',
        message: formData.message.trim(),
      });

      // Send email directly to agrapujyainstitute@gmail.com
      sendEmailNotification({
        _subject: `[Agra Pujya Institute] New Website Enquiry from ${formData.name.trim()}: ${formData.subject.trim() || 'General Enquiry'}`,
        'Sender Name': formData.name.trim(),
        'Phone Number': formData.phone.trim(),
        'Email Address': formData.email.trim() || 'Not Provided',
        'Subject': formData.subject.trim() || 'General Enquiry',
        'Message Content': formData.message.trim(),
        'Received At': new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
      });

      setSubmitted(true);
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    } catch {
      setErrorMessage('Failed to send message. Please call +91 8339888551 directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const cleanWhatsappNumber = location.whatsappNumber.replace(/[^0-9]/g, '');
  const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
    location.address
  )}`;

  return (
    <section id="contact" className="py-20 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest uppercase text-blue-700 mb-2">
            <MessageSquare className="w-3.5 h-3.5 text-amber-500" />
            <span>Connect & Visit</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 tracking-tight">
            Contact Us
          </h2>
          <p className="mt-3 text-slate-600 text-base">
            Reach out directly for admissions, child sponsorships, volunteer programs, or visit our center in Hinjilicut.
          </p>
          <div className="w-14 h-1 bg-amber-500 mx-auto mt-4 rounded-full" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Left Column: Organization & Contact Cards */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#FAF8F5] rounded-2xl p-7 border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block mb-1">
                Official Headquarters
              </span>
              <h3 className="font-serif text-2xl font-bold text-slate-900 mb-1">
                {organizationName}
              </h3>
              <p className="text-xs text-slate-500 mb-6">
                Founded & Led by <strong>{founder.name}</strong>
              </p>

              <div className="space-y-4 text-sm text-slate-700">
                {/* Address */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 border border-blue-100">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900 block text-xs uppercase tracking-wide">
                      Campus Location
                    </span>
                    <p className="mt-0.5 leading-relaxed">{location.address}</p>
                  </div>
                </div>

                {/* Phones */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 border border-blue-100">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900 block text-xs uppercase tracking-wide">
                      Helpline & Admissions
                    </span>
                    <div className="mt-0.5 space-y-0.5 font-mono text-xs sm:text-sm">
                      <a href={`tel:${location.primaryPhone}`} className="block hover:text-blue-700 transition-colors">
                        {location.primaryPhone}
                      </a>
                      <a href={`tel:${location.secondaryPhone}`} className="block hover:text-blue-700 transition-colors">
                        {location.secondaryPhone}
                      </a>
                    </div>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center shrink-0 border border-blue-100">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900 block text-xs uppercase tracking-wide">
                      Official Email
                    </span>
                    <a
                      href={`mailto:${location.email}`}
                      className="mt-0.5 block text-xs sm:text-sm text-blue-700 hover:underline break-all"
                    >
                      {location.email}
                    </a>
                  </div>
                </div>
              </div>

              {/* Action Buttons: WhatsApp & Google Maps Directions */}
              <div className="mt-8 pt-6 border-t border-stone-200 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href={`https://wa.me/${cleanWhatsappNumber}?text=${encodeURIComponent(
                    'Hello Prahalad Sir, I am contacting you regarding Agra Pujya Institute (A.P.I).'
                  )}`}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp Chat</span>
                </a>

                <a
                  href={directionsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="py-2.5 px-3 rounded-xl bg-[#0A192F] hover:bg-[#122B4F] text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-xs transition-colors"
                >
                  <Navigation className="w-4 h-4 text-amber-400" />
                  <span>Get Directions</span>
                </a>
              </div>
            </div>

            {/* Embedded Google Map */}
            <div className="rounded-2xl overflow-hidden border border-stone-200 shadow-xs aspect-[16/10] bg-stone-100 relative">
              <iframe
                title="Agra Pujya Institute Hinjilicut Map Location"
                src={`https://maps.google.com/maps?q=${encodeURIComponent(
                  location.mapQuery
                )}&t=&z=14&ie=UTF8&iwloc=&output=embed`}
                className="w-full h-full border-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>

          {/* Right Column: Contact Enquiry Form */}
          <div className="lg:col-span-7">
            <div className="bg-[#FAF8F5] rounded-2xl p-7 sm:p-9 border border-stone-200 shadow-xs">
              <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block mb-1">
                Direct Communication
              </span>
              <h3 className="font-serif text-2xl font-bold text-slate-900 mb-2">
                Send an Enquiry to Founder & Administration
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 mb-6">
                Have questions regarding syllabus, admission assistance, student sponsorship, or book donations? Send a note below.
              </p>

              {submitted ? (
                <div className="p-8 text-center bg-white rounded-xl border border-emerald-200">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-3">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="font-serif text-xl font-bold text-slate-900 mb-1">
                    Thank You for Reaching Out
                  </h4>
                  <p className="text-xs text-slate-600 mb-2 leading-relaxed max-w-sm mx-auto">
                    Your message has been received and dispatched directly to <strong>{ADMIN_EMAIL}</strong>.
                  </p>
                  <p className="text-[11px] text-slate-400 mb-4">
                    Founder Prahalad Behera or administrative staff will respond to you promptly.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {errorMessage && (
                    <div className="p-3 bg-rose-50 text-rose-800 text-xs rounded-lg border border-rose-200">
                      {errorMessage}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Anandita Panda"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-white rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="+91 8339888551"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-white rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        placeholder="anandita@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-white rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Subject
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Free admission guidance / Book donation"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="w-full px-3.5 py-2 text-xs sm:text-sm bg-white rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Your Message *
                    </label>
                    <textarea
                      rows={4}
                      required
                      placeholder="Write your message or question here..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-3.5 py-2 text-xs sm:text-sm bg-white rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3 px-6 text-xs sm:text-sm font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                      <span>{isSubmitting ? 'Sending Message...' : 'Send Message'}</span>
                    </button>
                    <p className="text-[11px] text-slate-500 text-center mt-2">
                      Direct notification to Prahalad Behera & Agra Pujya Institute admin
                    </p>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
