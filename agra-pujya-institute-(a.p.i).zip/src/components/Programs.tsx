import { useState } from 'react';
import { BookOpen, Check, ArrowRight, X, Sparkles, GraduationCap } from 'lucide-react';
import { EducationalProgram } from '../types';

interface ProgramsProps {
  programs: EducationalProgram[];
  onEnquire: (programTitle: string) => void;
}

export default function Programs({ programs, onEnquire }: ProgramsProps) {
  const [selectedProgram, setSelectedProgram] = useState<EducationalProgram | null>(null);

  return (
    <section id="programs" className="py-20 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest uppercase text-blue-700 mb-2">
            <GraduationCap className="w-3.5 h-3.5 text-amber-500" />
            <span>Academic Curriculum & Skills</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 tracking-tight">
            Our Educational Programs
          </h2>
          <p className="mt-3 text-slate-600 text-base">
            From foundational school education to university degrees and job-ready digital vocational skills.
          </p>
          <div className="w-14 h-1 bg-amber-500 mx-auto mt-4 rounded-full" />
        </div>

        {/* 4 Program Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {programs.map((prog, index) => (
            <div
              key={prog.id}
              className="bg-[#FAF8F5] rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between group"
            >
              {/* Image with subtle hover zoom */}
              <div>
                <div className="relative aspect-[16/10] overflow-hidden bg-stone-200">
                  <img
                    src={prog.image}
                    alt={prog.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3 bg-slate-950/80 backdrop-blur-xs text-amber-300 text-[11px] font-semibold px-2.5 py-1 rounded">
                    Program {index + 1}
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 sm:p-6">
                  <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block mb-1">
                    {prog.subtitle}
                  </span>
                  <h3 className="font-serif font-bold text-lg sm:text-xl text-slate-900 mb-2.5 leading-snug">
                    {prog.title}
                  </h3>
                  <p className="text-slate-600 text-xs sm:text-sm line-clamp-3 mb-4 leading-relaxed">
                    {prog.description}
                  </p>

                  <div className="space-y-2 pt-2 border-t border-stone-200 text-xs text-slate-700">
                    {prog.curriculumPoints.slice(0, 3).map((point, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <Check className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{point}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-5 sm:p-6 pt-0 space-y-2">
                <button
                  onClick={() => setSelectedProgram(prog)}
                  className="w-full py-2 px-3 text-xs font-semibold text-slate-700 bg-white border border-stone-300 hover:bg-stone-50 rounded-lg transition-colors cursor-pointer"
                >
                  Learn More
                </button>
                <button
                  onClick={() => onEnquire(prog.title)}
                  className="w-full py-2 px-3 text-xs font-bold text-white bg-[#0A192F] hover:bg-[#122B4F] rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>Admission Enquiry</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Program Details Modal */}
      {selectedProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-stone-200 p-6 sm:p-8 relative">
            <button
              onClick={() => setSelectedProgram(null)}
              aria-label="Close modal"
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-semibold text-blue-700 uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>{selectedProgram.subtitle}</span>
            </div>

            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
              {selectedProgram.title}
            </h3>

            <p className="text-sm font-medium text-slate-500 mb-6">
              Level: {selectedProgram.level} · Medium: {selectedProgram.medium}
            </p>

            <div className="relative aspect-video rounded-xl overflow-hidden mb-6 bg-stone-100">
              <img
                src={selectedProgram.image}
                alt={selectedProgram.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <p className="text-slate-700 text-sm sm:text-base leading-relaxed mb-6">
              {selectedProgram.description}
            </p>

            <div className="mb-6">
              <h4 className="font-semibold text-slate-900 text-sm uppercase tracking-wider mb-3">
                Key Curriculum & Academic Features:
              </h4>
              <ul className="space-y-2.5 text-sm text-slate-700">
                {selectedProgram.curriculumPoints.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2.5">
                    <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 mb-6">
              <strong>Zero-Fee Notice:</strong> Qualified orphaned students and children from economically needy families
              can enroll in this course with 100% free tuition and sponsored materials.
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-stone-200">
              <button
                onClick={() => setSelectedProgram(null)}
                className="w-full sm:w-auto px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-stone-100 rounded-lg transition-colors cursor-pointer"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const title = selectedProgram.title;
                  setSelectedProgram(null);
                  onEnquire(title);
                }}
                className="w-full sm:w-auto px-6 py-2.5 text-sm font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-lg shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Submit Admission Enquiry</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
