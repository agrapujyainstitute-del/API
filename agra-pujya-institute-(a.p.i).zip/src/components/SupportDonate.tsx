import { useState } from 'react';
import { Heart, BookOpen, Building, Laptop, UserCheck, ShieldCheck, Mail, Phone, CheckCircle, ArrowRight, X, QrCode, Copy, Check, Building2, CreditCard, Smartphone, Sparkles } from 'lucide-react';
import { SiteContent } from '../types';
import { sendEmailNotification, ADMIN_EMAIL } from '../services/emailService';

interface SupportDonateProps {
  content: SiteContent;
  onOpenVolunteer: () => void;
  onOpenContact: () => void;
}

export default function SupportDonate({ content, onOpenVolunteer, onOpenContact }: SupportDonateProps) {
  const { donationConfig, location, founder, bankDetails } = content;
  const [pledgeModalOpen, setPledgeModalOpen] = useState(false);
  const [selectedCause, setSelectedCause] = useState<string>('Sponsor a Child\'s Education');
  const [pledgeSubmitted, setPledgeSubmitted] = useState(false);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, label: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopiedField(label);
      setTimeout(() => setCopiedField(null), 2500);
    } catch {
      // fallback
    }
  };
  const [pledgeForm, setPledgeForm] = useState({
    name: '',
    phone: '',
    email: '',
    city: '',
    intendedContribution: 'Academic Stationery / Books',
    notes: '',
  });

  const supportOptions = [
    {
      id: 'sponsor-child',
      title: 'Sponsor a Child\'s Education',
      description: 'Cover tuition, notebooks, and coaching guidance for an orphaned or underprivileged child for a full academic term.',
      icon: Heart,
      type: 'Direct Child Mentorship',
    },
    {
      id: 'learning-materials',
      title: 'Support Learning Materials',
      description: 'Contribute school textbooks, notebooks, geometry sets, and question bank reference guides for classroom study.',
      icon: BookOpen,
      type: 'Books & Stationery',
    },
    {
      id: 'improve-facilities',
      title: 'Help Improve Classroom Facilities',
      description: 'Assist in maintaining clean benches, whiteboards, classroom lighting, and hygienic learning areas in Hinjilicut.',
      icon: Building,
      type: 'Infrastructure',
    },
    {
      id: 'digital-education',
      title: 'Support Digital Education',
      description: 'Help sponsor computer lab maintenance, peripheral accessories, and software training for rural youth.',
      icon: Laptop,
      type: 'Digital Literacy',
    },
    {
      id: 'volunteer-skills',
      title: 'Volunteer Your Time & Skills',
      description: 'Share your academic knowledge in mathematics, science, or computer design as a guest tutor or mentor.',
      icon: UserCheck,
      type: 'Mentorship',
    },
  ];

  const handlePledgeSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Send email directly to agrapujyainstitute@gmail.com
    sendEmailNotification({
      _subject: `[Agra Pujya Institute] New Educational Support Pledge from ${pledgeForm.name.trim()}`,
      'Supporter Full Name': pledgeForm.name.trim(),
      'Phone Number': pledgeForm.phone.trim(),
      'Email Address': pledgeForm.email.trim() || 'Not Provided',
      'Selected Cause': selectedCause,
      'Intended Contribution': pledgeForm.intendedContribution,
      'Notes / City': pledgeForm.notes.trim() || 'None',
      'Pledged At': new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
    });

    setPledgeSubmitted(true);
  };

  return (
    <section id="support" className="py-24 bg-[#0A192F] text-white relative overflow-hidden border-b border-stone-800">
      {/* Background aesthetics */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold tracking-widest uppercase text-amber-400 mb-3">
            <Heart className="w-4 h-4 text-rose-400" />
            <span>Community Sponsorship & Partnership</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-white tracking-tight leading-tight">
            BE THE REASON A CHILD CAN DREAM BIG.
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto">
            Your support can help make quality education more accessible to children who need it most.
          </p>
          <div className="w-16 h-1 bg-amber-400 mx-auto mt-6 rounded-full" />
        </div>

        {/* Official QR Code & Direct Bank Transfer Showcase */}
        {bankDetails?.active !== false && (
          <div className="max-w-5xl mx-auto mb-16 bg-gradient-to-br from-white/10 to-white/5 border border-amber-400/30 rounded-3xl p-6 sm:p-9 shadow-2xl backdrop-blur-md">
            <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8 lg:gap-12">
              {/* Left Column: QR Code Container */}
              <div className="w-full sm:w-auto shrink-0 flex flex-col items-center">
                <div className="bg-white p-4 sm:p-5 rounded-2xl shadow-xl border-2 border-amber-400/40 text-center relative group">
                  <div className="w-48 h-48 sm:w-56 sm:h-56 bg-stone-100 rounded-xl overflow-hidden flex items-center justify-center">
                    <img
                      src={
                        bankDetails?.qrCodeImage && bankDetails.qrCodeImage.trim()
                          ? bankDetails.qrCodeImage
                          : `https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=8&data=${encodeURIComponent(
                              `upi://pay?pa=${bankDetails?.upiId || 'agrapujyainstitute@sbi'}&pn=${encodeURIComponent(
                                bankDetails?.accountName || 'AGRA PUJYA INSTITUTE'
                              )}&cu=INR`
                            )}`
                      }
                      alt="Agra Pujya Institute Donation QR Code"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="mt-3 flex items-center justify-center gap-1.5 text-xs font-bold text-slate-900 uppercase tracking-wider">
                    <QrCode className="w-3.5 h-3.5 text-amber-600" />
                    <span>Scan to Donate</span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    PhonePe · Google Pay · Paytm · BHIM
                  </p>
                </div>

                <div className="mt-4 flex flex-wrap justify-center gap-1.5 text-[10px] uppercase font-bold tracking-wider text-amber-300">
                  <span className="bg-white/10 px-2 py-0.5 rounded">All UPI Apps</span>
                  <span className="bg-white/10 px-2 py-0.5 rounded">0% Fee</span>
                  <span className="bg-white/10 px-2 py-0.5 rounded">100% Tax Free</span>
                </div>
              </div>

              {/* Right Column: Bank Account Details with 1-Click Copy */}
              <div className="flex-1 w-full">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 text-amber-300 text-xs font-semibold mb-3 border border-amber-400/30">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Direct Social Contribution Account</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-white mb-2">
                  Bank Transfer & UPI Contribution
                </h3>
                <p className="text-sm text-slate-300 mb-6 leading-relaxed">
                  Support our zero-fee orphaned children and student coaching. Every rupee directly funds textbooks, study notebooks, and classroom mentorship in Hinjilicut.
                </p>

                {/* Details Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                  {/* Account Name */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-3.5 sm:col-span-2">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                        Account Holder Name
                      </span>
                      <Building2 className="w-3.5 h-3.5 text-amber-400" />
                    </div>
                    <p className="font-bold text-white text-sm sm:text-base mt-1 tracking-wide">
                      {bankDetails?.accountName || 'AGRA PUJYA INSTITUTE'}
                    </p>
                  </div>

                  {/* Bank Name */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-3.5">
                    <span className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold block">
                      Bank Name
                    </span>
                    <p className="font-bold text-white text-sm mt-1">
                      {bankDetails?.bankName || 'State Bank of India'}
                    </p>
                  </div>

                  {/* Branch */}
                  <div className="bg-white/5 border border-white/10 rounded-xl p-3.5">
                    <span className="text-slate-400 text-[11px] uppercase tracking-wider font-semibold block">
                      Branch
                    </span>
                    <p className="font-medium text-white text-xs mt-1 truncate">
                      {bankDetails?.branch || 'Hinjilicut, Ganjam, Odisha'}
                    </p>
                  </div>

                  {/* Account Number with Copy */}
                  <div className="bg-white/5 border border-amber-400/30 rounded-xl p-3.5 flex items-center justify-between">
                    <div>
                      <span className="text-amber-300 text-[11px] uppercase tracking-wider font-semibold block">
                        Account Number
                      </span>
                      <p className="font-mono font-bold text-white text-sm sm:text-base mt-0.5 tracking-wider">
                        {bankDetails?.accountNumber || '41238910293'}
                      </p>
                    </div>
                    <button
                      onClick={() => handleCopy(bankDetails?.accountNumber || '41238910293', 'Account Number')}
                      className="px-3 py-1.5 rounded-lg bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 hover:text-white transition-colors flex items-center gap-1 font-medium cursor-pointer"
                      title="Copy Account Number"
                    >
                      {copiedField === 'Account Number' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* IFSC Code with Copy */}
                  <div className="bg-white/5 border border-amber-400/30 rounded-xl p-3.5 flex items-center justify-between">
                    <div>
                      <span className="text-amber-300 text-[11px] uppercase tracking-wider font-semibold block">
                        IFSC Code
                      </span>
                      <p className="font-mono font-bold text-white text-sm sm:text-base mt-0.5 tracking-wider">
                        {bankDetails?.ifscCode || 'SBIN0001234'}
                      </p>
                    </div>
                    <button
                      onClick={() => handleCopy(bankDetails?.ifscCode || 'SBIN0001234', 'IFSC Code')}
                      className="px-3 py-1.5 rounded-lg bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 hover:text-white transition-colors flex items-center gap-1 font-medium cursor-pointer"
                      title="Copy IFSC Code"
                    >
                      {copiedField === 'IFSC Code' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* UPI ID with Copy (Span 2) */}
                  <div className="bg-white/5 border border-blue-400/30 rounded-xl p-3.5 sm:col-span-2 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                        <Smartphone className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-blue-300 text-[11px] uppercase tracking-wider font-semibold block">
                          Official UPI ID / VPA
                        </span>
                        <p className="font-mono font-bold text-white text-sm sm:text-base mt-0.5">
                          {bankDetails?.upiId || 'agrapujyainstitute@sbi'}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCopy(bankDetails?.upiId || 'agrapujyainstitute@sbi', 'UPI ID')}
                      className="px-3 py-1.5 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 hover:text-white transition-colors flex items-center gap-1 font-medium cursor-pointer shrink-0"
                      title="Copy UPI ID"
                    >
                      {copiedField === 'UPI ID' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy UPI</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Transparency Note */}
                <div className="mt-5 p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs text-slate-300 flex items-start gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Official Receipt Note:</strong> After transferring, please share your transaction reference or screenshot via WhatsApp (<strong>+91 8339888551</strong>) or email (<strong>agrapujyainstitute@gmail.com</strong>) to receive an official acknowledgement.
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 5 Support Options Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-14">
          {supportOptions.map((opt) => {
            const Icon = opt.icon;
            return (
              <div
                key={opt.id}
                className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:border-amber-400/40 hover:bg-white/[0.08] transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-amber-400/10 text-amber-400 flex items-center justify-center mb-5 border border-amber-400/20 group-hover:scale-105 transition-transform">
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider block mb-1">
                    {opt.type}
                  </span>
                  <h3 className="text-lg font-serif font-bold text-white mb-2">
                    {opt.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {opt.description}
                  </p>
                </div>

                <button
                  onClick={() => {
                    setSelectedCause(opt.title);
                    setPledgeSubmitted(false);
                    setPledgeModalOpen(true);
                  }}
                  className="w-full py-2.5 px-3 text-xs font-semibold text-amber-300 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>Connect to Support</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}

          {/* Quick Contact Card inside grid */}
          <div className="bg-gradient-to-br from-blue-900/40 to-slate-900 border border-blue-400/30 rounded-2xl p-6 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-semibold text-blue-300 uppercase tracking-wider block mb-1">
                Direct Administrative Contact
              </span>
              <h3 className="text-lg font-serif font-bold text-white mb-2">
                Speak with Founder
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                Discuss custom academic sponsorships, book drives, or visit our Hinjilicut center directly.
              </p>
              <div className="space-y-2 text-xs text-slate-300">
                <p className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>{location.primaryPhone}</span>
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-amber-400" />
                  <span>{location.email}</span>
                </p>
              </div>
            </div>

            <button
              onClick={onOpenContact}
              className="mt-6 w-full py-2.5 px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors cursor-pointer"
            >
              Contact Our Team
            </button>
          </div>
        </div>

        {/* 3 Main Action Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-4 border-t border-white/10">
          <button
            onClick={() => {
              setSelectedCause('Sponsor a Child\'s Education');
              setPledgeSubmitted(false);
              setPledgeModalOpen(true);
            }}
            className="px-6 py-3 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 rounded-xl shadow-lg transition-all cursor-pointer flex items-center gap-2"
          >
            <Heart className="w-4 h-4 text-slate-950" />
            <span>Support Now / Pledge</span>
          </button>

          <button
            onClick={onOpenVolunteer}
            className="px-6 py-3 text-sm font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/20 rounded-xl transition-all cursor-pointer flex items-center gap-2"
          >
            <UserCheck className="w-4 h-4 text-amber-300" />
            <span>Become a Volunteer</span>
          </button>

          <button
            onClick={onOpenContact}
            className="px-6 py-3 text-sm font-semibold text-slate-200 hover:text-white bg-transparent hover:bg-white/5 border border-white/15 rounded-xl transition-all cursor-pointer flex items-center gap-2"
          >
            <Mail className="w-4 h-4" />
            <span>Contact Our Team</span>
          </button>
        </div>
      </div>

      {/* Support / Pledge Modal */}
      {pledgeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs text-slate-900">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl border border-stone-200">
            <button
              onClick={() => setPledgeModalOpen(false)}
              aria-label="Close modal"
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {pledgeSubmitted ? (
              <div className="text-center py-8">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-2xl font-bold text-slate-900 mb-2">
                  Thank You for Your Heartfelt Support!
                </h3>
                <p className="text-sm text-slate-600 mb-6 leading-relaxed">
                  Your sponsorship intention for <strong>{selectedCause}</strong> has been recorded.
                  Founder Prahalad Behera or an administrative representative will contact you at{' '}
                  <strong>{pledgeForm.phone || pledgeForm.email}</strong> to coordinate details.
                </p>
                <button
                  onClick={() => setPledgeModalOpen(false)}
                  className="px-6 py-2.5 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl"
                >
                  Close Window
                </button>
              </div>
            ) : (
              <div>
                <div className="mb-5">
                  <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block">
                    Support Intention & Educational Pledge
                  </span>
                  <h3 className="font-serif text-2xl font-bold text-slate-900">
                    {selectedCause}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Directly aiding underprivileged learners at Agra Pujya Institute, Hinjilicut.
                  </p>
                </div>

                <form onSubmit={handlePledgeSubmit} className="space-y-3.5 text-xs">
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Your Full Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Ramesh Chandra Das"
                      value={pledgeForm.name}
                      onChange={(e) => setPledgeForm({ ...pledgeForm, name: e.target.value })}
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Phone Number *</label>
                      <input
                        type="tel"
                        required
                        placeholder="+91 9876543210"
                        value={pledgeForm.phone}
                        onChange={(e) => setPledgeForm({ ...pledgeForm, phone: e.target.value })}
                        className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-700 mb-1">Email Address</label>
                      <input
                        type="email"
                        placeholder="yourname@gmail.com"
                        value={pledgeForm.email}
                        onChange={(e) => setPledgeForm({ ...pledgeForm, email: e.target.value })}
                        className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Type of Support Intended *</label>
                    <select
                      value={pledgeForm.intendedContribution}
                      onChange={(e) => setPledgeForm({ ...pledgeForm, intendedContribution: e.target.value })}
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none bg-white"
                    >
                      <option value="Academic Stationery / Books">Academic Books, Notebooks & Stationery</option>
                      <option value="Child Coaching Sponsorship">Monthly / Annual Child Coaching Sponsorship</option>
                      <option value="Computer Lab Equipment">Computer Lab Equipment / Hardware</option>
                      <option value="Classroom Infrastructure">Classroom Furniture / Whiteboards</option>
                      <option value="In-person Visit / Other">In-person Visit to Hinjilicut Center</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 mb-1">Message or Specific Location</label>
                    <textarea
                      rows={2}
                      placeholder="Any specific note or how you'd like to coordinate..."
                      value={pledgeForm.notes}
                      onChange={(e) => setPledgeForm({ ...pledgeForm, notes: e.target.value })}
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-2.5 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                    >
                      Confirm Support Intention
                    </button>
                    <p className="text-[10px] text-slate-500 text-center mt-2">
                      Zero commercial transactions online · Direct community coordination
                    </p>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
