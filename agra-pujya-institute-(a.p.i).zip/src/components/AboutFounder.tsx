import { User, MapPin, Calendar, BookOpen, Quote, CheckCircle } from 'lucide-react';
import { SiteContent } from '../types';

interface AboutFounderProps {
  content: SiteContent;
  onOpenMessageEdit?: () => void;
}

export default function AboutFounder({ content }: AboutFounderProps) {
  const { founder, location, establishedYear } = content;

  return (
    <section id="about" className="py-20 bg-[#FAF8F5] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-16">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-blue-700 mb-2">
              <span>About Our NGO</span>
              <span aria-hidden="true">·</span>
              <span>Hinjilicut, Ganjam</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 tracking-tight leading-tight">
              Who We Are – Our Story, Our Purpose
            </h2>
            <div className="w-16 h-1 bg-amber-500 mt-4 rounded-full" />
          </div>

          <div className="flex items-center gap-3 p-3 bg-white rounded-2xl border border-stone-200 shadow-xs shrink-0 sm:max-w-xs">
            <img
              src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
              alt="Agra Pujya Institute Emblem"
              className="w-12 h-12 object-contain shrink-0"
            />
            <div className="text-xs">
              <span className="font-bold text-slate-900 block leading-tight">Agra Pujya Institute</span>
              <span className="text-[11px] font-serif italic text-amber-700 block mt-0.5">
                &ldquo;Our goal is good education, good character&rdquo;
              </span>
            </div>
          </div>
        </div>

        {/* Narrative & Institutional Background */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Main Story Paragraphs */}
          <div className="lg:col-span-7 space-y-6 text-slate-700 leading-relaxed text-base sm:text-lg">
            <p className="font-serif text-xl sm:text-2xl text-slate-900 font-medium leading-snug">
              AGRA PUJYA INSTITUTE is a community-centric educational initiative dedicated to democratizing quality
              learning.
            </p>

            <p>
              Established in {establishedYear} in Hinjilicut, our core mission is to bridge the educational gap and ensure
              that financial constraints never impede a student&apos;s pursuit of excellence.
            </p>

            <p>
              Founded and led by <strong>{founder.name}</strong>, the institute is driven by a deep commitment to social
              impact, education and community development across southern Odisha.
            </p>

            <p>
              We strive to create an inclusive environment where academic guidance is accessible to every deserving
              student, fostering self-reliance, intellectual curiosity, and long-term societal progress.
            </p>

            {/* Quick Facts Strip (Quiet unboxed metadata) */}
            <div className="pt-6 border-t border-stone-200 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs text-slate-600">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-900 block">Location</span>
                  <span>{location.city}, {location.district}, {location.state}</span>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <Calendar className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-900 block">Established</span>
                  <span>Year {establishedYear}</span>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <User className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-900 block">Leadership</span>
                  <span>{founder.name}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Founder Presentation & Portrait */}
          <div className="lg:col-span-5">
            <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden p-6 sm:p-7">
              <div className="relative aspect-[3/4] min-h-[460px] max-h-[580px] w-full rounded-2xl overflow-hidden bg-stone-100 mb-6 shadow-sm border border-stone-200 group">
                <img
                  src={founder.image || '/assets/images/founder_prahalad_official.png'}
                  alt={`Founder ${founder.name} - Agra Pujya Institute`}
                  className="w-full h-full object-cover object-top group-hover:scale-[1.02] transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/15 to-transparent" />
                <div className="absolute top-3.5 right-3.5 bg-emerald-700/90 backdrop-blur-xs text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-md flex items-center gap-1.5 border border-emerald-400/40">
                  <CheckCircle className="w-3.5 h-3.5 text-amber-300" />
                  <span>Founder &amp; Educator</span>
                </div>
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <p className="font-serif font-bold text-xl sm:text-2xl leading-tight text-white drop-shadow-sm">
                    {founder.name}
                  </p>
                  <p className="text-xs text-amber-300 font-medium tracking-wide uppercase mt-1">
                    {founder.role} · Hinjilicut, Odisha
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
                  <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                  <span>Founder Profile</span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {founder.bio}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Message from Our Founder Section */}
        <div className="mt-16 bg-white rounded-2xl border border-stone-200 shadow-xs p-8 sm:p-10 relative overflow-hidden">
          <div className="max-w-4xl">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-wider uppercase text-amber-700 mb-3">
              <Quote className="w-4 h-4 text-amber-600" />
              <span>Official Address</span>
            </div>

            <h3 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 mb-6">
              A Message from Our Founder
            </h3>

            <div className="relative pl-6 sm:pl-8 border-l-2 border-amber-400">
              <p className="text-base sm:text-lg text-slate-700 italic font-serif leading-relaxed">
                &ldquo;{founder.message}&rdquo;
              </p>
              <div className="mt-6 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-slate-900 text-amber-400 flex items-center justify-center font-bold text-xs">
                  PB
                </div>
                <div>
                  <p className="font-semibold text-slate-900 text-sm">{founder.name}</p>
                  <p className="text-xs text-slate-500">Founder & Leader, Agra Pujya Institute (A.P.I)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
