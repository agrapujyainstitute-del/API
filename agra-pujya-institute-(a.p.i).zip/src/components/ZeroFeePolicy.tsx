import { ShieldCheck, HeartHandshake, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import { SiteContent } from '../types';

interface ZeroFeePolicyProps {
  content: SiteContent;
  onApplyFreeEducation: (category?: string) => void;
}

export default function ZeroFeePolicy({ content, onApplyFreeEducation }: ZeroFeePolicyProps) {
  const { zeroFeePolicy } = content;

  return (
    <section id="zero-fee" className="py-24 bg-gradient-to-b from-[#FAF8F5] via-white to-[#FAF8F5] relative overflow-hidden border-b border-stone-200">
      {/* Decorative background aura */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-amber-400/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header with emotional weight */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-amber-700 bg-amber-50 border border-amber-200/80 px-3.5 py-1.5 rounded-full mb-4">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Our Core Commitment · 100% Free Access</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-slate-900 tracking-tight leading-tight text-balance">
            NO CHILD SHOULD BE LEFT BEHIND BECAUSE OF POVERTY.
          </h2>

          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto">
            At Agra Pujya Institute, we uphold an uncompromising principle: quality education, dedicated mentorship,
            and academic materials must be accessible to every deserving child without exception.
          </p>

          <div className="w-16 h-1 bg-amber-500 mx-auto mt-6 rounded-full" />
        </div>

        {/* Feature Image Banner with authentic documentary feeling */}
        <div className="relative rounded-2xl overflow-hidden shadow-lg border border-stone-200 mb-12 max-w-5xl mx-auto">
          <div className="aspect-[16/9] sm:aspect-[21/9] w-full bg-stone-100">
            <img
              src="/assets/images/zero_fee_students_1794191606094.jpg"
              alt="Indian school children studying joyfully together in Hinjilicut classroom"
              className="w-full h-full object-cover object-center filter contrast-[1.03]"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex items-end">
            <div className="p-6 sm:p-8 text-white max-w-2xl">
              <span className="text-xs uppercase tracking-widest font-semibold text-amber-300 block mb-1">
                Real Grassroots Impact in Odisha
              </span>
              <p className="font-serif text-lg sm:text-xl font-medium leading-snug">
                Every child who enters our institute receives individualized attention, respect, and unconditional academic support.
              </p>
            </div>
          </div>
        </div>

        {/* The Two Premium Pillars / Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* CARD 1 – 100% FREE EDUCATION FOR ORPHANS */}
          <div className="bg-white rounded-2xl p-8 sm:p-10 border-2 border-blue-600/30 shadow-md flex flex-col justify-between hover:border-blue-600 transition-all group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-100 group-hover:scale-105 transition-transform">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 px-3 py-1 rounded-md border border-blue-100">
                  Zero Fee Guaranteed
                </span>
              </div>

              <h3 className="text-2xl font-serif font-bold text-slate-900 mb-4 leading-snug">
                100% FREE EDUCATION FOR ORPHANS
              </h3>

              <p className="text-slate-700 text-base leading-relaxed mb-6">
                {zeroFeePolicy.orphanPolicy}
              </p>

              <div className="space-y-3 pt-4 border-t border-stone-100 text-sm text-slate-600">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>Full tuition waiver for all primary, secondary, and higher secondary courses</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>Free access to study notebooks, question banks, and learning stationery</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                  <span>Continuous personal mentorship and emotional encouragement</span>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-stone-100">
              <button
                onClick={() => onApplyFreeEducation('Free Education for Orphans')}
                className="w-full py-3 px-4 text-sm font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs group-hover:shadow-md"
              >
                <span>Apply for Orphan Scholarship</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* CARD 2 – 100% SPONSORED EDUCATION FOR NEEDY STUDENTS */}
          <div className="bg-white rounded-2xl p-8 sm:p-10 border-2 border-amber-500/30 shadow-md flex flex-col justify-between hover:border-amber-500 transition-all group">
            <div>
              <div className="flex items-center justify-between mb-6">
                <div className="w-14 h-14 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center border border-amber-100 group-hover:scale-105 transition-transform">
                  <HeartHandshake className="w-7 h-7" />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-3 py-1 rounded-md border border-amber-100">
                  100% Sponsored
                </span>
              </div>

              <h3 className="text-2xl font-serif font-bold text-slate-900 mb-4 leading-snug">
                100% SPONSORED EDUCATION FOR NEEDY STUDENTS
              </h3>

              <p className="text-slate-700 text-base leading-relaxed mb-6">
                {zeroFeePolicy.needyPolicy}
              </p>

              <div className="space-y-3 pt-4 border-t border-stone-100 text-sm text-slate-600">
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>Support for children from daily-wage, agrarian, and low-income households</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>Free computer training and digital literacy laboratory access</span>
                </div>
                <div className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>Board examination preparation and test series without any hidden charges</span>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-stone-100">
              <button
                onClick={() => onApplyFreeEducation('Sponsored Education for Economically Needy Students')}
                className="w-full py-3 px-4 text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs group-hover:shadow-md"
              >
                <span>Apply for Needy Student Sponsorship</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Big Central Action Button */}
        <div className="mt-14 text-center">
          <button
            onClick={() => onApplyFreeEducation()}
            className="inline-flex items-center gap-3 px-8 py-4 text-base font-bold text-white bg-slate-950 hover:bg-slate-900 rounded-xl shadow-xl hover:shadow-2xl transition-all cursor-pointer group active:scale-[0.99]"
          >
            <span className="tracking-wide">APPLY FOR FREE EDUCATION</span>
            <ArrowRight className="w-5 h-5 text-amber-400 group-hover:translate-x-1 transition-transform" />
          </button>
          <p className="text-xs text-slate-500 mt-3">
            Simple application process · Direct review by founder Prahalad Behera & faculty committee
          </p>
        </div>
      </div>
    </section>
  );
}
