import { useState } from 'react';
import { GalleryItem, GalleryCategory } from '../types';
import { Camera, ZoomIn, X, ChevronLeft, ChevronRight } from 'lucide-react';

interface GalleryProps {
  items: GalleryItem[];
}

export default function Gallery({ items }: GalleryProps) {
  const [activeCategory, setActiveCategory] = useState<GalleryCategory>('All');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const categories: GalleryCategory[] = [
    'All',
    'Classroom Activities',
    'Students Learning',
    'Computer Education',
    'Educational Events',
    'Community Activities',
    'Institute Facilities',
  ];

  const filteredItems =
    activeCategory === 'All' ? items : items.filter((item) => item.category === activeCategory);

  const handleNext = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex + 1) % filteredItems.length);
    }
  };

  const handlePrev = () => {
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex - 1 + filteredItems.length) % filteredItems.length);
    }
  };

  return (
    <section id="gallery" className="py-20 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-12">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest uppercase text-blue-700 mb-2">
            <Camera className="w-3.5 h-3.5 text-amber-500" />
            <span>Visual Chronicles</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 tracking-tight">
            Gallery – Stories of Hope
          </h2>
          <p className="mt-3 text-slate-600 text-base">
            Capturing daily moments of academic curiosity, digital learning, and community dedication in Hinjilicut.
          </p>
          <div className="w-14 h-1 bg-amber-500 mx-auto mt-4 rounded-full" />
        </div>

        {/* Category Filter Tabs (Interactive controls as permitted in §1.A) */}
        <div className="flex items-center justify-start sm:justify-center gap-1.5 overflow-x-auto pb-4 mb-10 text-xs scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${
                activeCategory === cat
                  ? 'bg-slate-950 text-white shadow-xs'
                  : 'bg-stone-100 text-slate-600 hover:text-slate-900 hover:bg-stone-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              onClick={() => setLightboxIndex(index)}
              className="group relative rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 shadow-xs hover:shadow-md cursor-pointer transition-all aspect-[4/3]"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                referrerPolicy="no-referrer"
              />

              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-5 text-white">
                <span className="text-[10px] uppercase font-bold tracking-wider text-amber-300 mb-1">
                  {item.category}
                </span>
                <h3 className="font-serif font-bold text-base leading-snug">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-200 line-clamp-2 mt-1">
                  {item.caption}
                </p>
                <div className="mt-3 flex items-center gap-1.5 text-xs text-amber-400 font-semibold">
                  <ZoomIn className="w-3.5 h-3.5" />
                  <span>View Full Photo</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12 text-slate-500 text-sm">
            No gallery items found in this category.
          </div>
        )}
      </div>

      {/* Lightbox Modal */}
      {lightboxIndex !== null && filteredItems[lightboxIndex] && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm">
          <button
            onClick={() => setLightboxIndex(null)}
            aria-label="Close lightbox"
            className="absolute top-4 right-4 p-2.5 text-white/70 hover:text-white bg-white/10 hover:bg-white/20 rounded-full transition-colors z-20 cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Prev/Next Controls */}
          {filteredItems.length > 1 && (
            <>
              <button
                onClick={handlePrev}
                aria-label="Previous photo"
                className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 text-white/80 hover:text-white bg-black/40 hover:bg-black/60 rounded-full transition-colors z-20 cursor-pointer"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={handleNext}
                aria-label="Next photo"
                className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 text-white/80 hover:text-white bg-black/40 hover:bg-black/60 rounded-full transition-colors z-20 cursor-pointer"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </>
          )}

          <div className="max-w-4xl w-full max-h-[90vh] flex flex-col items-center">
            <div className="relative max-h-[70vh] rounded-xl overflow-hidden shadow-2xl">
              <img
                src={filteredItems[lightboxIndex].image}
                alt={filteredItems[lightboxIndex].title}
                className="max-h-[70vh] w-auto object-contain mx-auto"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="mt-4 text-center text-white max-w-2xl px-4">
              <span className="text-xs uppercase tracking-wider text-amber-400 font-bold">
                {filteredItems[lightboxIndex].category}
              </span>
              <h3 className="font-serif text-xl font-bold mt-1">
                {filteredItems[lightboxIndex].title}
              </h3>
              <p className="text-sm text-slate-300 mt-1 leading-relaxed">
                {filteredItems[lightboxIndex].caption}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
