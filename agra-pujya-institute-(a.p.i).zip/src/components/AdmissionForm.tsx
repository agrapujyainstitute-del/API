import { useState, useEffect } from 'react';
import { GraduationCap, ShieldCheck, CheckCircle2, AlertCircle, ArrowRight, Mail } from 'lucide-react';
import { ApplicationCategory, MediumType, AdmissionApplication } from '../types';
import { db } from '../services/db';
import { sendEmailNotification, ADMIN_EMAIL } from '../services/emailService';

interface AdmissionFormProps {
  initialCategory?: ApplicationCategory;
  initialCourse?: string;
  onApplicationSubmitted?: (application: AdmissionApplication) => void;
}

export default function AdmissionForm({
  initialCategory,
  initialCourse,
  onApplicationSubmitted,
}: AdmissionFormProps) {
  const [formData, setFormData] = useState({
    studentName: '',
    parentName: '',
    mobileNumber: '',
    email: '',
    address: '',
    classLevel: '',
    medium: 'Odia' as MediumType,
    courseInterest: initialCourse || 'Primary & Secondary Education (Class 1-10)',
    category: (initialCategory || 'Free Education for Orphans') as ApplicationCategory,
    additionalInfo: '',
    privacyConsent: false,
  });

  useEffect(() => {
    if (initialCategory) {
      setFormData((prev) => ({ ...prev, category: initialCategory }));
    }
  }, [initialCategory]);

  useEffect(() => {
    if (initialCourse) {
      setFormData((prev) => ({ ...prev, courseInterest: initialCourse }));
    }
  }, [initialCourse]);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedApp, setSubmittedApp] = useState<AdmissionApplication | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const courses = [
    'Primary & Secondary Education (Classes 1 to 10)',
    'Higher Secondary Education (+2 all streams: Arts, Commerce and Science)',
    'Degree Level Education (+3 all streams: Arts, Commerce and Science)',
    'Professional Skill Development (Computer Fundamentals)',
    'Graphic Design (Adobe Photoshop Training)',
    'General Foundation & Doubt Clearing Mentorship',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Form validation
    if (!formData.studentName.trim() || !formData.parentName.trim() || !formData.mobileNumber.trim()) {
      setErrorMessage('Please fill in all required fields (Student Name, Parent Name, Mobile Number).');
      return;
    }

    if (!formData.privacyConsent) {
      setErrorMessage('Please accept the privacy consent to allow our faculty to review your academic information.');
      return;
    }

    // Basic mobile validation (India: 10 digits)
    const cleanedMobile = formData.mobileNumber.replace(/[^0-9]/g, '');
    if (cleanedMobile.length < 10) {
      setErrorMessage('Please enter a valid 10-digit mobile number for communication.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate real async database insertion into db.ts
      await new Promise((resolve) => setTimeout(resolve, 600));

      const newApp = db.submitApplication({
        studentName: formData.studentName.trim(),
        parentName: formData.parentName.trim(),
        mobileNumber: formData.mobileNumber.trim(),
        email: formData.email.trim() || undefined,
        address: formData.address.trim(),
        classLevel: formData.classLevel.trim(),
        medium: formData.medium,
        courseInterest: formData.courseInterest,
        category: formData.category,
        additionalInfo: formData.additionalInfo.trim() || undefined,
      });

      // Send instant email notification to agrapujyainstitute@gmail.com
      sendEmailNotification({
        _subject: `[Agra Pujya Institute] New Admission Form: ${formData.studentName.trim()} (${formData.category})`,
        'Application Reference ID': newApp.id,
        'Student Full Name': formData.studentName.trim(),
        'Parent / Guardian Name': formData.parentName.trim(),
        'Mobile Number (WhatsApp)': formData.mobileNumber.trim(),
        'Student Email': formData.email.trim() || 'Not Provided',
        'Application Category': formData.category,
        'Class / Educational Level': formData.classLevel.trim(),
        'Medium of Instruction': formData.medium,
        'Course Interested In': formData.courseInterest,
        'Residential Address': formData.address.trim(),
        'Additional Information / Hardship': formData.additionalInfo.trim() || 'None provided',
        'Submitted At': new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
      });

      setSubmittedApp(newApp);
      if (onApplicationSubmitted) {
        onApplicationSubmitted(newApp);
      }
    } catch {
      setErrorMessage('An unexpected error occurred while saving your application. Please call +91 8339888551 directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmittedApp(null);
    setFormData({
      studentName: '',
      parentName: '',
      mobileNumber: '',
      email: '',
      address: '',
      classLevel: '',
      medium: 'Odia',
      courseInterest: 'Primary & Secondary Education (Classes 1 to 10)',
      category: 'Free Education for Orphans',
      additionalInfo: '',
      privacyConsent: false,
    });
  };

  return (
    <section id="apply" className="py-14 sm:py-20 bg-[#FAF8F5] border-b border-stone-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-3.5 px-5 py-2.5 bg-white rounded-2xl border border-stone-200/90 shadow-xs mb-4">
            <img
              src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
              alt="Agra Pujya Institute Official Emblem"
              className="h-11 sm:h-12 w-auto object-contain shrink-0 drop-shadow-xs"
            />
            <div className="text-left border-l border-stone-200 pl-3.5">
              <span className="block font-serif font-bold text-xs sm:text-sm tracking-wide text-[#0A192F]">
                AGRA PUJYA INSTITUTE
              </span>
              <span className="block text-[10px] sm:text-[11px] font-semibold text-blue-700 tracking-wider uppercase">
                Official Application Portal · Hinjilicut
              </span>
            </div>
          </div>

          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 tracking-tight leading-tight">
            Admission &amp; Free Education Application
          </h2>
          <p className="mt-3 text-slate-600 text-sm sm:text-base max-w-2xl mx-auto leading-relaxed">
            Apply for zero-fee sponsorship (for orphaned or economically needy students) or general enrollment at Agra Pujya Institute.
          </p>
          <div className="w-14 h-1 bg-amber-500 mx-auto mt-4 rounded-full" />
        </div>

        {submittedApp ? (
          /* Real Success Confirmation Screen */
          <div className="bg-white rounded-2xl border-2 border-emerald-500/40 p-8 sm:p-12 shadow-lg text-center animate-fade-in">
            <div className="h-14 w-auto mx-auto mb-4 flex items-center justify-center">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
                alt="Agra Pujya Institute Logo"
                className="h-14 w-auto object-contain"
              />
            </div>
            <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <span className="text-xs font-bold uppercase tracking-widest text-emerald-700 bg-emerald-50 px-3 py-1 rounded-md border border-emerald-200">
              Application Successfully Registered
            </span>

            <h3 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 mt-4 mb-2">
              Welcome, {submittedApp.studentName}!
            </h3>

            <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mb-6 leading-relaxed">
              Your application has been received and securely stored in our administrative system. Founder Prahalad Behera
              and our counseling staff will review your request under the{' '}
              <strong className="text-slate-900">{submittedApp.category}</strong> category.
            </p>

            <div className="bg-stone-50 border border-stone-200 rounded-xl p-6 max-w-md mx-auto text-left text-xs text-slate-700 space-y-2 mb-8">
              <div className="flex justify-between py-1 border-b border-stone-200">
                <span className="text-slate-500">Application Reference ID:</span>
                <span className="font-mono font-bold text-slate-900">{submittedApp.id}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-stone-200">
                <span className="text-slate-500">Student Name:</span>
                <span className="font-semibold text-slate-900">{submittedApp.studentName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-stone-200">
                <span className="text-slate-500">Category:</span>
                <span className="font-semibold text-blue-700">{submittedApp.category}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-stone-200">
                <span className="text-slate-500">Selected Course:</span>
                <span className="font-medium text-slate-900">{submittedApp.courseInterest}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">Contact Number:</span>
                <span className="font-medium text-slate-900">{submittedApp.mobileNumber}</span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-2 text-xs text-slate-600 mb-6 bg-blue-50/80 p-2.5 rounded-lg border border-blue-100 max-w-md mx-auto">
              <Mail className="w-4 h-4 text-blue-700 shrink-0" />
              <span>Application details sent to <strong>{ADMIN_EMAIL}</strong></span>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={handleReset}
                className="w-full sm:w-auto px-6 py-2.5 text-xs font-semibold text-slate-700 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors cursor-pointer"
              >
                Submit Another Application
              </button>
              <a
                href="https://wa.me/918339888551?text=Hello%20Prahalad%20Sir,%20I%20have%20submitted%20admission%20application"
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
              >
                <span>Notify via WhatsApp</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ) : (
          /* Form Card */
          <div className="bg-white rounded-2xl border border-stone-200 shadow-md p-6 sm:p-10">
            {errorMessage && (
              <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <p>{errorMessage}</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Category Selector with zero-pill visual clarity */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                  Application Category *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    {
                      id: 'Free Education for Orphans',
                      title: 'Free for Orphans',
                      sub: '100% Zero-fee tuition & books',
                    },
                    {
                      id: 'Sponsored Education for Economically Needy Students',
                      title: 'Sponsored Needy',
                      sub: 'Family hardship support',
                    },
                    {
                      id: 'General Admission',
                      title: 'General Admission',
                      sub: 'Subsidized regular coaching',
                    },
                  ].map((cat) => (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => setFormData({ ...formData, category: cat.id as ApplicationCategory })}
                      className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        formData.category === cat.id
                          ? 'border-blue-700 bg-blue-50/70 ring-1 ring-blue-700'
                          : 'border-stone-200 bg-stone-50/50 hover:bg-stone-100/60'
                      }`}
                    >
                      <span className="block font-bold text-xs text-slate-900">{cat.title}</span>
                      <span className="block text-[11px] text-slate-500 mt-0.5">{cat.sub}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Student and Parent Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Student Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Lipun Nayak"
                    value={formData.studentName}
                    onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Parent / Guardian Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Kalu Charan Nayak"
                    value={formData.parentName}
                    onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              {/* Contact Information */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Mobile Number (WhatsApp preferred) *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+91 8339888551"
                    value={formData.mobileNumber}
                    onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Email Address (Optional)
                  </label>
                  <input
                    type="email"
                    placeholder="student@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>
              </div>

              {/* Academic Level & Medium */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Current Class / Educational Level *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Class 10 / +2 1st Year Science / +3 Arts"
                    value={formData.classLevel}
                    onChange={(e) => setFormData({ ...formData, classLevel: e.target.value })}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Medium of Study *
                  </label>
                  <select
                    value={formData.medium}
                    onChange={(e) => setFormData({ ...formData, medium: e.target.value as MediumType })}
                    className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none bg-white"
                  >
                    <option value="Odia">Odia Medium</option>
                    <option value="English">English Medium</option>
                    <option value="Both">Bilingual / Both</option>
                  </select>
                </div>
              </div>

              {/* Course Interested In */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Course Interested In *
                </label>
                <select
                  value={formData.courseInterest}
                  onChange={(e) => setFormData({ ...formData, courseInterest: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none bg-white"
                >
                  {courses.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              {/* Residential Address */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Residential Address (Village / Ward / Street, Hinjilicut & Surrounding) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Near Jagannath Temple, Hinjilicut, Ganjam"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              {/* Additional Information / Reason for Free Education */}
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Additional Information (Family background or reason for free sponsorship)
                </label>
                <textarea
                  rows={3}
                  placeholder="Please mention any details regarding parental loss, family hardship, or specific academic subjects requiring support..."
                  value={formData.additionalInfo}
                  onChange={(e) => setFormData({ ...formData, additionalInfo: e.target.value })}
                  className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-stone-300 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>

              {/* Privacy Consent */}
              <div className="pt-2">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.privacyConsent}
                    onChange={(e) => setFormData({ ...formData, privacyConsent: e.target.checked })}
                    className="mt-1 h-4 w-4 rounded border-stone-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-xs text-slate-600 leading-normal">
                    I confirm that the details provided are accurate to the best of my knowledge, and I consent to Agra Pujya
                    Institute contacting me regarding academic counseling, documentation verification, and admission.
                  </span>
                </label>
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Applications securely stored & handled by institute admin</span>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full sm:w-auto px-8 py-3 text-sm font-bold text-white bg-[#0A192F] hover:bg-[#122B4F] rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>Registering Application...</span>
                  ) : (
                    <>
                      <span>Submit Application</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </section>
  );
}
