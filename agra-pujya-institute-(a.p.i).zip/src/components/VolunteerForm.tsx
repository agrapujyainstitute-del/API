import { useState } from 'react';
import { UserCheck, CheckCircle2, HeartHandshake, ArrowRight, X, Mail } from 'lucide-react';
import { db } from '../services/db';
import { sendEmailNotification, ADMIN_EMAIL } from '../services/emailService';

interface VolunteerFormProps {
  isOpen?: boolean;
  onClose?: () => void;
  isInline?: boolean;
}

export default function VolunteerForm({ isOpen = true, onClose, isInline = false }: VolunteerFormProps) {
  const [formData, setFormData] = useState({
    fullName: '',
    contactNumber: '',
    email: '',
    skills: '',
    areaOfInterest: 'Teaching High School Subjects (Math / Science / English)',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const areas = [
    'Teaching High School Subjects (Math / Science / English)',
    'Computer & Digital Literacy Tutoring',
    'Graphic Design & Creative Workshop Mentorship',
    'Career Guidance & College Admission Counseling',
    'Study Material & Book Distribution Support',
    'Community Outreach in Hinjilicut & Surrounding Blocks',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!formData.fullName.trim() || !formData.contactNumber.trim() || !formData.skills.trim()) {
      setErrorMessage('Please fill in your name, contact number, and skills.');
      return;
    }

    setIsSubmitting(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      db.submitVolunteer({
        fullName: formData.fullName.trim(),
        contactNumber: formData.contactNumber.trim(),
        email: formData.email.trim(),
        skills: formData.skills.trim(),
        areaOfInterest: formData.areaOfInterest,
        message: formData.message.trim(),
      });

      // Send email directly to agrapujyainstitute@gmail.com
      sendEmailNotification({
        _subject: `[Agra Pujya Institute] New Volunteer Registration: ${formData.fullName.trim()}`,
        'Volunteer Full Name': formData.fullName.trim(),
        'Contact Number': formData.contactNumber.trim(),
        'Email Address': formData.email.trim() || 'Not Provided',
        'Skills & Background': formData.skills.trim(),
        'Area of Interest': formData.areaOfInterest,
        'Message / Availability': formData.message.trim() || 'None',
        'Registered At': new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }),
      });

      setSubmitted(true);
    } catch {
      setErrorMessage('Failed to submit registration. Please contact +91 8339888551.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const content = (
    <div className="bg-white rounded-2xl border border-stone-200 shadow-xl p-6 sm:p-8 max-w-xl w-full relative">
      {onClose && (
        <button
          onClick={onClose}
          aria-label="Close volunteer form"
          className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-stone-100 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      )}

      {submitted ? (
        <div className="text-center py-6">
          <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="font-serif text-2xl font-bold text-slate-900 mb-2">
            Thank You for Stepping Forward!
          </h3>
          <p className="text-sm text-slate-600 mb-6 leading-relaxed">
            Your volunteer application has been received. Our team will contact you to welcome you to the Agra Pujya Institute
            community of educators and changemakers in Hinjilicut.
          </p>
          {onClose && (
            <button
              onClick={onClose}
              className="px-6 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl"
            >
              Done
            </button>
          )}
        </div>
      ) : (
        <div>
          <div className="mb-6">
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-amber-700 mb-2">
              <HeartHandshake className="w-4 h-4 text-amber-600" />
              <span>Join Our Community of Educators</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-slate-900">
              Together, We Can Make Education Accessible.
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              Whether you can teach 2 hours on weekends or assist with computer sessions, your contribution shapes young futures.
            </p>
          </div>

          {errorMessage && (
            <div className="mb-4 p-3 bg-rose-50 text-rose-800 text-xs rounded-lg border border-rose-200">
              {errorMessage}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Full Name *</label>
              <input
                type="text"
                required
                placeholder="e.g. Satyabrata Sahu"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Contact Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="+91 9437000000"
                  value={formData.contactNumber}
                  onChange={(e) => setFormData({ ...formData, contactNumber: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">Email Address</label>
                <input
                  type="email"
                  placeholder="your.email@gmail.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Your Skills / Academic Background *</label>
              <input
                type="text"
                required
                placeholder="e.g. M.Sc Physics / B.Tech / English Grammar / Graphic Design"
                value={formData.skills}
                onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Area of Interest *</label>
              <select
                value={formData.areaOfInterest}
                onChange={(e) => setFormData({ ...formData, areaOfInterest: e.target.value })}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none bg-white"
              >
                {areas.map((a) => (
                  <option key={a} value={a}>
                    {a}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Message / Availability</label>
              <textarea
                rows={2}
                placeholder="Share your schedule or how you would like to help..."
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                className="w-full px-3 py-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                <UserCheck className="w-4 h-4" />
                <span>{isSubmitting ? 'Registering...' : 'Become a Volunteer'}</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );

  if (isInline) {
    return <div className="max-w-xl mx-auto">{content}</div>;
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      {content}
    </div>
  );
}
