import { ArrowDown, GraduationCap, Heart, Sparkles } from 'lucide-react';

interface HeroProps {
  onExploreMission: () => void;
  onSupportCause: () => void;
  onApplyFree: () => void;
}

export default function Hero({ onExploreMission, onSupportCause, onApplyFree }: HeroProps) {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center bg-[#071324] text-white overflow-hidden">
      {/* Background Hero Image with measured film contrast scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/assets/images/hero_child_studying_1794191606058.jpg"
          alt="Indian student reading open textbooks in a warm classroom in Hinjilicut, Odisha"
          className="w-full h-full object-cover object-center filter brightness-[0.75] contrast-[1.05]"
          referrerPolicy="no-referrer"
        />
        {/* Editorial gradient overlays for high legibility */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#060E1E] via-[#0A192F]/70 to-[#0A192F]/40" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#060E1E]/90 via-[#0A192F]/60 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
        <div className="max-w-3xl">
          {/* Official Emblem & Institutional Kicker */}
          <div className="inline-flex items-center gap-4 sm:gap-5 mb-8 bg-white/10 backdrop-blur-md rounded-2xl p-2.5 sm:p-3 pr-5 sm:pr-6 border border-white/20 shadow-2xl">
            <div className="bg-white rounded-xl p-1.5 shadow-md shrink-0 flex items-center justify-center">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
                alt="Agra Pujya Institute Official Logo"
                className="h-14 sm:h-16 w-auto object-contain"
              />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-bold tracking-wider uppercase text-amber-300">
                <span>Agra Pujya Institute</span>
                <span className="text-amber-400/80">·</span>
                <span>Hinjilicut, Odisha</span>
                <span className="text-amber-400/80">·</span>
                <span className="text-white/80 font-normal">Estd. 2022</span>
              </div>
              <p className="text-xs sm:text-sm font-serif italic text-amber-100 mt-0.5">
                &ldquo;Our goal is good education, good character&rdquo;
              </p>
            </div>
          </div>

          {/* Main Headline */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-white tracking-tight leading-[1.15] text-balance mb-4">
            EDUCATION IS NOT A PRIVILEGE.{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-200 to-amber-400">
              IT IS EVERY CHILD&apos;S RIGHT.
            </span>
          </h1>

          {/* Supporting Headline */}
          <p className="text-lg sm:text-xl font-medium text-amber-100/90 tracking-wide mb-5">
            Empowering Minds, Transforming Futures.
          </p>

          {/* Description */}
          <p className="text-base sm:text-lg text-slate-200/90 leading-relaxed max-w-2xl text-pretty mb-8">
            At Agra Pujya Institute, we believe that financial difficulties should never become a barrier to education.
            Since 2022, we have been working towards creating educational opportunities for children and students from
            economically disadvantaged backgrounds.
          </p>

          {/* The 3 CTAs */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 pt-2">
            {/* CTA 3: Apply for Free Education (High prominence) */}
            <button
              onClick={onApplyFree}
              className="px-5 py-3 text-sm font-bold text-[#060E1E] bg-gradient-to-r from-amber-400 via-amber-300 to-amber-400 rounded-lg shadow-lg hover:shadow-amber-500/25 hover:from-amber-300 hover:to-amber-200 transition-all cursor-pointer whitespace-nowrap active:scale-[0.98] inline-flex items-center gap-2"
            >
              <GraduationCap className="w-4 h-4 text-[#060E1E]" />
              <span>Apply for Free Education</span>
            </button>

            {/* CTA 2: Support Our Cause */}
            <button
              onClick={onSupportCause}
              className="px-5 py-3 text-sm font-semibold text-white bg-blue-600/90 hover:bg-blue-600 border border-blue-400/30 rounded-lg shadow-md transition-all cursor-pointer whitespace-nowrap active:scale-[0.98] inline-flex items-center gap-2"
            >
              <Heart className="w-4 h-4 text-rose-300" />
              <span>Support Our Cause</span>
            </button>

            {/* CTA 1: Explore Our Mission */}
            <button
              onClick={onExploreMission}
              className="px-5 py-3 text-sm font-medium text-slate-200 hover:text-white bg-white/10 hover:bg-white/15 border border-white/20 rounded-lg backdrop-blur-xs transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Explore Our Mission</span>
            </button>
          </div>

          {/* Core Foundation Highlights */}
          <div className="mt-12 pt-6 border-t border-white/15 grid grid-cols-2 sm:grid-cols-3 gap-6 text-slate-300 text-xs sm:text-sm">
            <div>
              <p className="font-semibold text-white text-base">100% Free for Orphans</p>
              <p className="text-slate-300 text-xs mt-0.5">Absolute zero-fee academic care</p>
            </div>
            <div>
              <p className="font-semibold text-white text-base">Sponsored for Needy</p>
              <p className="text-slate-300 text-xs mt-0.5">Overcoming financial distress</p>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <p className="font-semibold text-white text-base">Hinjilicut Community</p>
              <p className="text-slate-300 text-xs mt-0.5">Dedicated grassroots impact</p>
            </div>
          </div>
        </div>
      </div>

      {/* Animated Scroll Indicator */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 hidden sm:flex flex-col items-center text-slate-400 hover:text-white transition-colors cursor-pointer">
        <a href="#about" aria-label="Scroll to about section" className="flex flex-col items-center gap-1 group">
          <span className="text-[11px] uppercase tracking-widest font-medium opacity-80 group-hover:opacity-100">
            Scroll to Discover
          </span>
          <ArrowDown className="w-4 h-4 animate-bounce text-amber-400" />
        </a>
      </div>
    </section>
  );
}
