import { Shield, Phone, Mail, MapPin, Heart } from 'lucide-react';
import { SiteContent } from '../types';

interface FooterProps {
  content: SiteContent;
  onOpenAdmin: () => void;
  onOpenApply: () => void;
  onOpenDonate: () => void;
}

export default function Footer({ content, onOpenAdmin, onOpenApply, onOpenDonate }: FooterProps) {
  const { location, founder, organizationName, tagline } = content;
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#060E1E] text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 mb-12">
          {/* Col 1: Brand & Ethos */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="bg-white p-1 rounded-xl shadow-md shrink-0 flex items-center justify-center">
                <img
                  src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
                  alt="Agra Pujya Institute Official Logo"
                  className="h-10 w-auto object-contain"
                />
              </div>
              <div className="flex flex-col">
                <span className="font-serif font-bold text-lg text-white tracking-tight">
                  {organizationName}
                </span>
                <span className="text-[11px] font-serif italic text-amber-300">
                  &ldquo;Our goal is good education, good character&rdquo;
                </span>
              </div>
            </div>

            <p className="text-amber-200/90 text-xs font-medium">
              &ldquo;{tagline}&rdquo;
            </p>

            <p className="text-slate-400 text-xs leading-relaxed max-w-md">
              A community-centric educational NGO in Hinjilicut, Ganjam, Odisha. Dedicated to democratizing quality
              academics through 100% free education for orphaned children and sponsored support for students in financial hardship.
            </p>

            <div className="pt-2 text-slate-300 text-xs">
              <span>Founded and led by </span>
              <strong className="text-white">{founder.name}</strong>
              <span> · Established 2022</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <p className="font-bold text-white uppercase tracking-wider text-[11px]">
              Explore
            </p>
            <ul className="space-y-2">
              <li>
                <a href="#about" className="hover:text-white transition-colors">
                  About Our NGO
                </a>
              </li>
              <li>
                <a href="#vision-mission" className="hover:text-white transition-colors">
                  Vision & Mission
                </a>
              </li>
              <li>
                <a href="#zero-fee" className="hover:text-white transition-colors">
                  Zero-Fee Policy
                </a>
              </li>
              <li>
                <a href="#programs" className="hover:text-white transition-colors">
                  Academic Programs
                </a>
              </li>
              <li>
                <a href="#impact" className="hover:text-white transition-colors">
                  Social Impact
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-white transition-colors">
                  Photo Gallery
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Programs & Admissions */}
          <div className="lg:col-span-2 space-y-3">
            <p className="font-bold text-white uppercase tracking-wider text-[11px]">
              Admissions
            </p>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={onOpenApply}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Free Orphan Coaching
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenApply}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Needy Student Sponsorship
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenApply}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Class 1–10 Foundation
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenApply}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  +2 all streams (Arts, Commerce and Science)
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenApply}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  +3 all streams (Arts, Commerce and Science)
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenApply}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Computer Lab & Design
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Hinjilicut Contact */}
          <div className="lg:col-span-3 space-y-3">
            <p className="font-bold text-white uppercase tracking-wider text-[11px]">
              Location & Contact
            </p>
            <div className="space-y-2.5 text-slate-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                <span>{location.address}</span>
              </p>
              <p className="flex items-center gap-2 font-mono">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{location.primaryPhone}</span>
              </p>
              <p className="flex items-center gap-2 font-mono">
                <Phone className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{location.secondaryPhone}</span>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="break-all">{location.email}</span>
              </p>
            </div>

            <div className="pt-2">
              <button
                onClick={onOpenDonate}
                className="w-full py-2 px-3 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Heart className="w-3.5 h-3.5 fill-slate-900" />
                <span>Support Hinjilicut Children</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Line Bar */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
          <p>
            &copy; {currentYear} {organizationName}. All rights reserved · Hinjilicut, Ganjam, Odisha.
          </p>

          <div className="flex items-center gap-4 text-xs">
            <a
              href="https://technicalprahalad.com/our-ngo-agra-pujya-institute/"
              target="_blank"
              rel="noreferrer"
              className="hover:text-slate-300 transition-colors"
            >
              Reference Archive
            </a>
            <span aria-hidden="true">·</span>
            <button
              onClick={onOpenAdmin}
              className="inline-flex items-center gap-1 text-slate-400 hover:text-amber-400 transition-colors cursor-pointer"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Management Portal</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
