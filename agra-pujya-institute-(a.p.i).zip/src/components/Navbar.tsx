import { useState, useEffect } from 'react';
import { Menu, X, Shield, Phone, HeartHandshake } from 'lucide-react';

interface NavbarProps {
  onOpenDonate: () => void;
  onOpenApply: () => void;
  onOpenAdmin: () => void;
}

export default function Navbar({ onOpenDonate, onOpenApply, onOpenAdmin }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Vision & Mission', href: '#vision-mission' },
    { label: 'Zero-Fee Policy', href: '#zero-fee' },
    { label: 'Programs', href: '#programs' },
    { label: 'Social Impact', href: '#impact' },
    { label: 'Gallery', href: '#gallery' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`sticky top-0 z-40 transition-all duration-200 border-b ${
        isScrolled
          ? 'bg-white/95 backdrop-blur-md border-slate-200 shadow-sm py-3'
          : 'bg-[#FAF8F5] border-slate-200/80 py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark (Single clean element) */}
          <a
            href="#"
            className="flex items-center gap-3 text-slate-900 group whitespace-nowrap shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
          >
            <div className="relative shrink-0 flex items-center justify-center group-hover:scale-105 transition-transform">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
                alt="Agra Pujya Institute Official Logo"
                className="h-11 sm:h-12 w-auto object-contain drop-shadow-xs"
              />
            </div>
            <div className="flex flex-col">
              <span className="font-serif font-bold text-base sm:text-lg tracking-tight text-[#0A192F] leading-tight">
                AGRA PUJYA INSTITUTE
              </span>
              <span className="text-[10px] sm:text-[11px] font-medium tracking-wider text-slate-500 uppercase">
                Hinjilicut, Odisha · Estd. 2022
              </span>
            </div>
          </a>

          {/* Zone 2: Concise Nav Links (Single line, whitespace-nowrap) */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-700">
            {navLinks.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="hover:text-[#1D4ED8] transition-colors whitespace-nowrap relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-[#1D4ED8] hover:after:w-full after:transition-all"
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: Primary Action & Controls */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenApply}
              className="hidden sm:inline-flex items-center justify-center px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:border-slate-400 hover:bg-slate-50 transition-colors whitespace-nowrap cursor-pointer shadow-xs"
            >
              Apply for Admission
            </button>

            <button
              onClick={onOpenDonate}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-amber-600 to-amber-500 rounded-lg hover:from-amber-700 hover:to-amber-600 shadow-sm transition-all whitespace-nowrap cursor-pointer active:scale-[0.98]"
            >
              <HeartHandshake className="w-4 h-4 text-amber-100" />
              <span>Support Our Cause</span>
            </button>

            <button
              onClick={onOpenAdmin}
              title="Admin Portal"
              aria-label="Open Admin Dashboard"
              className="p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              <Shield className="w-4 h-4" />
            </button>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
              className="lg:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-[65px] bg-white border-b border-slate-200 shadow-xl px-5 py-6 transition-all duration-200 z-50">
          <nav className="flex flex-col space-y-3 pb-5 border-b border-slate-100">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-medium text-slate-800 hover:text-blue-700 py-1 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-4 flex flex-col gap-2.5">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenApply();
              }}
              className="w-full text-center py-2.5 text-sm font-semibold text-white bg-[#0A192F] hover:bg-[#122B4F] rounded-lg shadow-sm"
            >
              Apply for Free Education
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenDonate();
              }}
              className="w-full text-center py-2.5 text-sm font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg shadow-sm"
            >
              Support Our Cause
            </button>
            <div className="flex items-center justify-between pt-3 text-xs text-slate-500">
              <a
                href="tel:+918339888551"
                className="inline-flex items-center gap-1.5 text-slate-700 font-medium"
              >
                <Phone className="w-3.5 h-3.5 text-blue-600" />
                +91 8339888551
              </a>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="text-blue-700 font-medium flex items-center gap-1"
              >
                <Shield className="w-3.5 h-3.5" />
                Admin Portal
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
