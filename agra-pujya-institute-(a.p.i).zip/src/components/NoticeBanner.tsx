import { useState } from 'react';
import { Megaphone, X, ArrowRight } from 'lucide-react';
import { Announcement } from '../types';

interface NoticeBannerProps {
  announcements: Announcement[];
  onApplyClick: () => void;
}

export default function NoticeBanner({ announcements, onApplyClick }: NoticeBannerProps) {
  const [dismissed, setDismissed] = useState(false);
  const activeNotice = announcements.find((a) => a.active);

  if (!activeNotice || dismissed) return null;

  return (
    <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 text-white text-xs sm:text-sm py-2 px-4 shadow-sm relative z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <span className="inline-flex items-center justify-center p-1 bg-amber-700/60 rounded text-amber-100 shrink-0">
            <Megaphone className="w-3.5 h-3.5" />
          </span>
          <span className="font-semibold tracking-wide uppercase text-[11px] bg-white/20 px-2 py-0.5 rounded text-white shrink-0">
            {activeNotice.date || 'Notice'}
          </span>
          <p className="truncate font-medium text-amber-50">
            <strong className="text-white font-semibold mr-1.5">{activeNotice.title}:</strong>
            {activeNotice.content}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onApplyClick}
            className="inline-flex items-center gap-1 text-xs font-semibold bg-white text-amber-900 px-2.5 py-1 rounded hover:bg-amber-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            Apply Free <ArrowRight className="w-3 h-3" />
          </button>
          <button
            onClick={() => setDismissed(true)}
            aria-label="Dismiss announcement"
            className="text-amber-100 hover:text-white transition-colors p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
