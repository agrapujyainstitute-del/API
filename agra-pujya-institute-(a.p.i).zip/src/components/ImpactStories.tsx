import { BookOpen, Users, Laptop, Heart } from 'lucide-react';

export default function ImpactStories() {
  const impactThemes = [
    {
      title: 'Equal Access to Education',
      tagline: 'Bridging the Socioeconomic Divide',
      description:
        'In semi-urban and rural areas of Ganjam, high coaching fees often force talented children from disadvantaged backgrounds to discontinue studies. Agra Pujya Institute provides an open door where economic adversity never restricts academic learning.',
      icon: BookOpen,
      image: '/assets/images/hero_child_studying_1794191606058.jpg',
      quote: 'When you give a child books and patience, their curiosity knows no boundaries.',
    },
    {
      title: 'Support for Underprivileged Children',
      tagline: 'Dignity, Care, and Zero-Fee Sponsorship',
      description:
        'Orphaned children face emotional trauma along with extreme financial scarcity. By guaranteeing zero fees and supplying free notebooks, textbooks, and personal mentoring, we restore their confidence and secure their educational continuity.',
      icon: Users,
      image: '/assets/images/zero_fee_students_1794191606094.jpg',
      quote: 'Education is the most sustainable antidote to generational hardship.',
    },
    {
      title: 'Digital & Professional Skill Development',
      tagline: 'Equipping Local Youth for Modern Careers',
      description:
        'Beyond school examinations, young minds need contemporary digital capabilities. Our practical training in computer fundamentals and Photoshop graphic design empowers students with skills for real-world employment and creative exploration.',
      icon: Laptop,
      image: '/assets/images/computer_lab_learning_1794191606995.jpg',
      quote: 'Practical digital literacy turns passive consumers into active creators.',
    },
  ];

  return (
    <section id="impact" className="py-20 bg-[#FAF8F5] border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest uppercase text-blue-700 mb-2">
            <Heart className="w-3.5 h-3.5 text-rose-500" />
            <span>Community Upliftment</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-slate-900 tracking-tight">
            Small Opportunities. Big Dreams. Brighter Futures.
          </h2>
          <p className="mt-4 text-slate-600 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto">
            How accessible, community-driven education transforms lives and strengthens local neighborhoods in Hinjilicut.
          </p>
          <div className="w-16 h-1 bg-amber-500 mx-auto mt-5 rounded-full" />
        </div>

        {/* 3 Impact Themes */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {impactThemes.map((theme, index) => {
            const Icon = theme.icon;
            return (
              <div
                key={theme.title}
                className="bg-white rounded-2xl border border-stone-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Documentary Style Visual Asset */}
                  <div className="relative aspect-[16/10] overflow-hidden bg-stone-100">
                    <img
                      src={theme.image}
                      alt={theme.title}
                      className="w-full h-full object-cover filter contrast-[1.02]"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 bg-[#0A192F]/80 backdrop-blur-xs text-white text-[11px] font-semibold px-2.5 py-1 rounded">
                      Pillar 0{index + 1}
                    </div>
                  </div>

                  <div className="p-6 sm:p-7">
                    <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center mb-4 border border-amber-100">
                      <Icon className="w-5 h-5" />
                    </div>

                    <p className="text-xs font-bold text-blue-700 uppercase tracking-wider mb-1">
                      {theme.tagline}
                    </p>
                    <h3 className="text-xl font-serif font-bold text-slate-900 mb-3">
                      {theme.title}
                    </h3>

                    <p className="text-slate-600 text-sm leading-relaxed mb-6">
                      {theme.description}
                    </p>
                  </div>
                </div>

                <div className="p-6 sm:p-7 pt-0">
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-100 text-xs italic font-serif text-slate-700">
                    &ldquo;{theme.quote}&rdquo;
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Authentic Transparency Note on Impact Numbers */}
        <div className="mt-12 text-center text-xs text-slate-500 max-w-xl mx-auto">
          <p>
            * Note on Transparency: Agra Pujya Institute prioritizes authentic human mentorship over inflated statistical
            claims. Specific enrollment metrics are cataloged in our administrative registry in Hinjilicut.
          </p>
        </div>
      </div>
    </section>
  );
}
