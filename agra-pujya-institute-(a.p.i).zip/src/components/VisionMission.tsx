import { Compass, Target, Sparkles, BookOpenCheck } from 'lucide-react';
import { SiteContent } from '../types';

interface VisionMissionProps {
  content: SiteContent;
}

export default function VisionMission({ content }: VisionMissionProps) {
  const { vision, mission } = content;

  return (
    <section id="vision-mission" className="py-20 bg-white border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-widest uppercase text-blue-700 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Guiding Principles</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-slate-900 tracking-tight">
            Our Vision & Mission
          </h2>
          <p className="mt-3 text-slate-600 text-sm sm:text-base">
            The foundational ethos driving our educational commitments across Hinjilicut.
          </p>
          <div className="w-12 h-1 bg-amber-500 mx-auto mt-4 rounded-full" />
        </div>

        {/* 2-Column Balanced Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
          {/* Vision Column */}
          <div className="bg-[#FAF8F5] rounded-2xl p-8 sm:p-10 border border-stone-200 shadow-xs flex flex-col justify-between relative overflow-hidden group hover:border-blue-300 transition-colors">
            <div className="relative z-10">
              <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-800 flex items-center justify-center mb-6 border border-blue-100">
                <Compass className="w-6 h-6" />
              </div>
              <p className="text-xs font-semibold tracking-wider uppercase text-blue-700 mb-2">
                OUR VISION
              </p>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 mb-4">
                Education for All
              </h3>
              <p className="text-base sm:text-lg text-slate-700 leading-relaxed font-serif italic mb-6">
                &ldquo;{vision}&rdquo;
              </p>
            </div>

            <div className="pt-6 border-t border-stone-200/80 text-xs text-slate-600 space-y-1.5">
              <p className="font-semibold text-slate-800 uppercase tracking-wider text-[11px]">Core Tenet</p>
              <p>Every child possesses infinite potential that deserves nurturing, regardless of socioeconomic background.</p>
            </div>
          </div>

          {/* Mission Column */}
          <div className="bg-[#FAF8F5] rounded-2xl p-8 sm:p-10 border border-stone-200 shadow-xs flex flex-col justify-between relative overflow-hidden group hover:border-amber-300 transition-colors">
            <div className="relative z-10">
              <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-800 flex items-center justify-center mb-6 border border-amber-100">
                <Target className="w-6 h-6" />
              </div>
              <p className="text-xs font-semibold tracking-wider uppercase text-amber-700 mb-2">
                OUR MISSION
              </p>
              <h3 className="text-2xl sm:text-3xl font-serif font-bold text-slate-900 mb-4">
                Breaking Financial Barriers to Education
              </h3>
              <p className="text-base sm:text-lg text-slate-700 leading-relaxed font-serif italic mb-6">
                &ldquo;{mission}&rdquo;
              </p>
            </div>

            <div className="pt-6 border-t border-stone-200/80 text-xs text-slate-600 space-y-1.5">
              <p className="font-semibold text-slate-800 uppercase tracking-wider text-[11px]">Action Strategy</p>
              <p>Practical tutoring, zero-fee orphan sponsorship, curriculum support, and vocational skills training.</p>
            </div>
          </div>
        </div>

        {/* Commitment Statement */}
        <div className="mt-10 p-6 rounded-xl bg-blue-900/5 border border-blue-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BookOpenCheck className="w-5 h-5 text-blue-700 shrink-0" />
            <p className="text-sm font-medium text-slate-800">
              Our absolute zero-fee commitment is dedicated directly to students with zero commercial intent.
            </p>
          </div>
          <a
            href="#zero-fee"
            className="text-xs font-semibold text-blue-700 hover:text-blue-900 whitespace-nowrap transition-colors"
          >
            Review our Zero-Fee Policy &rarr;
          </a>
        </div>
      </div>
    </section>
  );
}
