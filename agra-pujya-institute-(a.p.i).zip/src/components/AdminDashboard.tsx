import { useState, useEffect } from 'react';
import {
  X,
  Lock,
  Unlock,
  GraduationCap,
  MessageSquare,
  Image as ImageIcon,
  Bell,
  Heart,
  Save,
  Download,
  Trash2,
  CheckCircle,
  Eye,
  EyeOff,
  LogOut,
  Search,
  QrCode,
  Shield,
  Building2,
  Upload,
  Phone,
  Calendar,
  ExternalLink,
  AlertTriangle,
  RefreshCw,
  Users,
  UserPlus,
  UserCheck,
} from 'lucide-react';
import {
  SiteContent,
  AdmissionApplication,
  ContactMessage,
  GalleryItem,
  Announcement,
  ApplicationStatus,
  BankDetails,
} from '../types';
import { db } from '../services/db';
import StudentFeeManager from './StudentFeeManager';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  onContentUpdated: (newContent: SiteContent) => void;
}

export default function AdminDashboard({ isOpen, onClose, onContentUpdated }: AdminDashboardProps) {
  // Authentication State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('api_admin_session') === 'active';
  });
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [lockoutTime, setLockoutTime] = useState<number | null>(null);

  // Active Tab - Default to Students & Fees Management
  const [activeTab, setActiveTab] = useState<'students' | 'applications' | 'bank-qr' | 'gallery' | 'announcements' | 'messages' | 'security'>('students');

  // Data states
  const [applications, setApplications] = useState<AdmissionApplication[]>([]);
  const [studentsCount, setStudentsCount] = useState<number>(() => db.getStudents().length);
  const [applicantToAdmit, setApplicantToAdmit] = useState<any | null>(null);
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [siteContent, setSiteContent] = useState<SiteContent>(db.getSiteContent());
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);

  // Bank & QR State
  const [bankForm, setBankForm] = useState<BankDetails>(siteContent.bankDetails || {
    accountName: 'AGRA PUJYA INSTITUTE',
    bankName: 'State Bank of India (SBI)',
    accountNumber: '39847291048',
    ifscCode: 'SBIN0000091',
    branch: 'Hinjilicut Main Branch, Ganjam, Odisha – 761102',
    upiId: 'agrapujyainstitute@sbi',
    qrCodeImage: '',
    active: true,
  });

  // Filter & Search states
  const [appFilter, setAppFilter] = useState<'All' | 'Orphans' | 'Needy' | 'General'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedApp, setSelectedApp] = useState<AdmissionApplication | null>(null);

  // New gallery item form
  const [newGallery, setNewGallery] = useState({
    title: '',
    category: 'Classroom Activities' as GalleryItem['category'],
    image: '',
    caption: '',
  });

  // New announcement form
  const [newAnn, setNewAnn] = useState({
    title: '',
    content: '',
    date: 'Academic Year 2026–27',
    priority: 'normal' as 'normal' | 'urgent',
  });

  // Password Change Form
  const [securityForm, setSecurityForm] = useState({
    email: 'agrapujyainstitute@gmail.com',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Check lockout
  useEffect(() => {
    if (lockoutTime && Date.now() < lockoutTime) {
      const timer = setTimeout(() => {
        setLockoutTime(null);
        setFailedAttempts(0);
      }, lockoutTime - Date.now());
      return () => clearTimeout(timer);
    }
  }, [lockoutTime]);

  // Load latest data when opened or authenticated
  useEffect(() => {
    if (isAuthenticated) {
      setApplications(db.getApplications());
      setStudentsCount(db.getStudents().length);
      setMessages(db.getContactMessages());
      const content = db.getSiteContent();
      setSiteContent(content);
      if (content.bankDetails) {
        setBankForm(content.bankDetails);
      }
      setGalleryItems(db.getGalleryItems());
      setAnnouncements(db.getAnnouncements());
      const creds = db.getAdminCredentials();
      setSecurityForm((prev) => ({ ...prev, email: creds.email }));
    }
  }, [isAuthenticated, isOpen, activeTab]);

  if (!isOpen) return null;

  // Handle Login with rate-limiting & zero exposed demo credentials
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (lockoutTime && Date.now() < lockoutTime) {
      const remainingSecs = Math.ceil((lockoutTime - Date.now()) / 1000);
      setAuthError(`Account temporarily locked due to multiple failed attempts. Please retry in ${remainingSecs} seconds.`);
      return;
    }

    const isValid = db.validateAdmin(adminEmail, adminPassword);

    if (isValid) {
      setIsAuthenticated(true);
      sessionStorage.setItem('api_admin_session', 'active');
      setFailedAttempts(0);
      setAuthError(null);
    } else {
      const newAttempts = failedAttempts + 1;
      setFailedAttempts(newAttempts);
      if (newAttempts >= 5) {
        const lockUntil = Date.now() + 10 * 60 * 1000; // 10 minutes lockout
        setLockoutTime(lockUntil);
        setAuthError('Too many failed login attempts. Security lock activated for 10 minutes.');
      } else {
        setAuthError(`Invalid administrator ID or password. (${5 - newAttempts} attempts remaining)`);
      }
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('api_admin_session');
    setAdminPassword('');
  };

  // Handle Bank & QR Update
  const handleSaveBankDetails = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = db.updateSiteContent({ bankDetails: bankForm });
    setSiteContent(updated);
    onContentUpdated(updated);
    showToast('Bank and QR Code donation details successfully updated live on website!');
  };

  // QR Code Image Upload handler (Base64 file reader)
  const handleQRImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Image file is too large. Please upload an image under 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        setBankForm((prev) => ({ ...prev, qrCodeImage: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Gallery Image Upload handler (Base64 file reader)
  const handleGalleryImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Image file is too large. Please upload an image under 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        const result = uploadEvent.target?.result as string;
        setNewGallery((prev) => ({ ...prev, image: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  // Application Actions
  const handleUpdateAppStatus = (id: string, status: ApplicationStatus, notes?: string) => {
    db.updateApplicationStatus(id, status, notes);
    const updated = db.getApplications();
    setApplications(updated);
    if (selectedApp && selectedApp.id === id) {
      setSelectedApp({ ...selectedApp, status, notes: notes !== undefined ? notes : selectedApp.notes });
    }
    showToast(`Application #${id} status changed to ${status}`);
  };

  const handleDeleteApplication = (id: string) => {
    if (confirm(`Are you sure you want to delete application #${id}? This record will be permanently removed.`)) {
      db.deleteApplication(id);
      setApplications(db.getApplications());
      if (selectedApp?.id === id) {
        setSelectedApp(null);
      }
      showToast(`Application #${id} deleted permanently.`);
    }
  };

  const handleAdmitFromApplication = (app: AdmissionApplication) => {
    setApplicantToAdmit({
      studentName: app.studentName,
      parentName: app.parentName,
      mobileNumber: app.mobileNumber,
      classLevel: app.classLevel || app.courseInterest,
      category: app.category,
      medium: app.medium,
    });
    // Update status to Enrolled
    db.updateApplicationStatus(app.id, 'Enrolled', 'Admitted to Student Register');
    setApplications(db.getApplications());
    setActiveTab('students');
    showToast(`Opening admission form for ${app.studentName}...`);
  };

  // Gallery Actions
  const handleAddGallery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGallery.title || !newGallery.image) {
      alert('Please provide a title and image URL or upload an image.');
      return;
    }
    db.addGalleryItem({
      title: newGallery.title,
      category: newGallery.category,
      image: newGallery.image,
      caption: newGallery.caption,
    });
    setGalleryItems(db.getGalleryItems());
    setNewGallery({
      title: '',
      category: 'Classroom Activities',
      image: '',
      caption: '',
    });
    showToast('New activity photo added to website gallery!');
  };

  const handleDeleteGallery = (id: string) => {
    if (confirm('Are you sure you want to delete this gallery photo?')) {
      db.deleteGalleryItem(id);
      setGalleryItems(db.getGalleryItems());
      showToast('Photo removed from gallery.');
    }
  };

  // Announcement Actions
  const handleAddAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAnn.title || !newAnn.content) return;
    const current = db.getAnnouncements();
    const item: Announcement = {
      id: `ann-${Date.now()}`,
      title: newAnn.title,
      content: newAnn.content,
      date: newAnn.date,
      priority: newAnn.priority,
      active: true,
    };
    const updated = [item, ...current];
    db.saveAnnouncements(updated);
    setAnnouncements(updated);
    setNewAnn({ title: '', content: '', date: 'Academic Year 2026–27', priority: 'normal' });
    showToast('New announcement ticker added to top banner!');
  };

  const handleToggleAnnouncement = (id: string) => {
    const list = db.getAnnouncements().map((a) => (a.id === id ? { ...a, active: !a.active } : a));
    db.saveAnnouncements(list);
    setAnnouncements(list);
  };

  const handleDeleteAnnouncement = (id: string) => {
    const list = db.getAnnouncements().filter((a) => a.id !== id);
    db.saveAnnouncements(list);
    setAnnouncements(list);
    showToast('Announcement deleted.');
  };

  // Password / Security update
  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    const creds = db.getAdminCredentials();
    if (securityForm.currentPassword !== creds.passwordHash) {
      alert('Current password does not match. Please verify your existing password.');
      return;
    }
    if (securityForm.newPassword.length < 6) {
      alert('New password must be at least 6 characters long.');
      return;
    }
    if (securityForm.newPassword !== securityForm.confirmPassword) {
      alert('New password and confirmation do not match.');
      return;
    }

    db.updateAdminCredentials(securityForm.email, securityForm.newPassword);
    setSecurityForm((prev) => ({
      ...prev,
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    }));
    showToast('Administrator credentials successfully updated!');
  };

  // CSV / JSON Export
  const handleDownloadCSV = () => {
    const csvContent = db.exportApplicationsAsCSV();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `api_hinjilicut_applications_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadJSON = () => {
    const jsonContent = db.exportAllDataAsJSON();
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `api_ngo_database_backup_${Date.now()}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filtered applications
  const filteredApps = applications.filter((app) => {
    const matchesFilter =
      appFilter === 'All'
        ? true
        : appFilter === 'Orphans'
        ? app.category.includes('Orphans')
        : appFilter === 'Needy'
        ? app.category.includes('Needy')
        : app.category.includes('General');

    const matchesSearch =
      searchQuery === ''
        ? true
        : app.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          app.mobileNumber.includes(searchQuery) ||
          app.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          app.classLevel.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-md text-slate-900">
      <div className="bg-white rounded-2xl w-full max-w-6xl h-[92vh] flex flex-col shadow-2xl border border-stone-200 overflow-hidden">
        {/* Modal Top Bar */}
        <div className="px-5 py-4 bg-[#0A192F] text-white flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="bg-white p-1 rounded-lg shrink-0 flex items-center justify-center">
              <img
                src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
                alt="Logo"
                className="w-8 h-8 object-contain"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm sm:text-base">Agra Pujya Institute</span>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded border border-amber-400/30">
                  Secure Admin Portal
                </span>
              </div>
              <p className="text-[11px] text-slate-300 hidden sm:block">
                Hinjilicut, Ganjam · Official Management Console
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 text-xs text-rose-300 hover:text-white hover:bg-rose-900/40 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                title="Secure Sign Out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Global Toast Message */}
        {toastMessage && (
          <div className="bg-emerald-600 text-white text-xs px-4 py-2 flex items-center justify-between font-medium animate-in fade-in">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{toastMessage}</span>
            </div>
            <button onClick={() => setToastMessage(null)} className="text-emerald-100 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {!isAuthenticated ? (
          /* Authentication Screen - Clean, locked, no demo credentials exposed */
          <div className="flex-1 overflow-y-auto flex items-center justify-center p-6 bg-stone-50">
            <div className="bg-white rounded-3xl border border-stone-200 p-8 sm:p-10 max-w-md w-full shadow-xl">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-stone-50 rounded-2xl p-2 shadow-inner border border-stone-200 flex items-center justify-center mx-auto mb-4">
                  <img
                    src="/assets/aistudio/WhatsApp_Image_2026-11-09_at_08.15.39_3e9095c9.jpeg"
                    alt="Agra Pujya Institute"
                    className="w-full h-full object-contain"
                  />
                </div>
                <h3 className="font-serif text-2xl font-bold text-slate-900">
                  Management Sign In
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Access admission applications, student sponsorships, QR donation account, and gallery management.
                </p>
              </div>

              {authError && (
                <div className="mb-5 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                  <span>{authError}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Administrator ID (Email) *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="agrapujyainstitute@gmail.com"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="font-medium text-slate-700">
                      Security Password *
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="text-slate-500 hover:text-slate-800 flex items-center gap-1 text-[11px]"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      <span>{showPassword ? 'Hide' : 'Show'}</span>
                    </button>
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="Enter management password"
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 border border-stone-300 rounded-xl focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={lockoutTime !== null && Date.now() < lockoutTime}
                    className="w-full py-3 px-4 text-xs font-bold text-white bg-[#0A192F] hover:bg-[#122B4F] disabled:bg-slate-400 rounded-xl shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
                  >
                    <Unlock className="w-4 h-4 text-amber-400" />
                    <span>Authorize & Access Dashboard</span>
                  </button>
                </div>
              </form>

              <div className="mt-8 pt-5 border-t border-stone-200 text-center text-[11px] text-slate-400">
                <p>Agra Pujya Institute · Hinjilicut, Odisha</p>
                <p className="mt-0.5">Authorized faculty access only. All actions logged.</p>
              </div>
            </div>
          </div>
        ) : (
          /* Authenticated Dashboard Layout */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Sidebar Navigation */}
            <div className="w-full md:w-64 bg-stone-50 border-r border-stone-200 p-3 sm:p-4 flex flex-col justify-between shrink-0 overflow-y-auto">
              <div className="space-y-1">
                <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                  Management Sections
                </div>

                <button
                  onClick={() => setActiveTab('students')}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === 'students'
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-stone-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Users className="w-4 h-4 text-amber-400" />
                    <span className="font-bold">Students &amp; Fees</span>
                  </div>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      activeTab === 'students' ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {studentsCount}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('applications')}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === 'applications'
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-stone-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <GraduationCap className="w-4 h-4" />
                    <span>Admissions</span>
                  </div>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                      activeTab === 'applications' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {applications.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveTab('bank-qr')}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === 'bank-qr'
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-stone-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <QrCode className="w-4 h-4 text-amber-500" />
                    <span>Bank & QR Settings</span>
                  </div>
                  <span className="text-[10px] text-emerald-600 font-bold">Active</span>
                </button>

                <button
                  onClick={() => setActiveTab('gallery')}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === 'gallery'
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-stone-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <ImageIcon className="w-4 h-4" />
                    <span>Activities Gallery</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{galleryItems.length}</span>
                </button>

                <button
                  onClick={() => setActiveTab('announcements')}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === 'announcements'
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-stone-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Bell className="w-4 h-4" />
                    <span>Notice Banners</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{announcements.length}</span>
                </button>

                <button
                  onClick={() => setActiveTab('messages')}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === 'messages'
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-stone-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <MessageSquare className="w-4 h-4" />
                    <span>Contact Messages</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">{messages.length}</span>
                </button>

                <button
                  onClick={() => setActiveTab('security')}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                    activeTab === 'security'
                      ? 'bg-blue-700 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-stone-200/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Shield className="w-4 h-4" />
                    <span>Security & Password</span>
                  </div>
                </button>
              </div>

              {/* Data Export Center */}
              <div className="pt-4 mt-4 border-t border-stone-200 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block px-1">
                  Database Backups
                </span>
                <button
                  onClick={handleDownloadCSV}
                  className="w-full py-2 px-3 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white border border-stone-200 rounded-lg hover:bg-stone-100 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-blue-600" />
                  <span>Export Admissions CSV</span>
                </button>
                <button
                  onClick={handleDownloadJSON}
                  className="w-full py-2 px-3 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white border border-stone-200 rounded-lg hover:bg-stone-100 transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                >
                  <Download className="w-3.5 h-3.5 text-amber-600" />
                  <span>Full NGO Backup (JSON)</span>
                </button>
              </div>
            </div>

            {/* Main Tab Content */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-white">
              {/* TAB 0: STUDENT & FEE MANAGEMENT SOFTWARE */}
              {activeTab === 'students' && (
                <StudentFeeManager
                  onNotify={showToast}
                  initialApplicantToAdmit={applicantToAdmit}
                  onClearInitialApplicant={() => setApplicantToAdmit(null)}
                />
              )}

              {/* TAB 1: APPLICATIONS & FREE EDUCATION */}
              {activeTab === 'applications' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-serif text-xl sm:text-2xl font-bold text-slate-900">
                        Admissions & Free Education Records
                      </h3>
                      <p className="text-xs text-slate-500 mt-0.5">
                        Manage orphan sponsorship applications and student enrollments.
                      </p>
                    </div>

                    {/* Filter Pills */}
                    <div className="flex flex-wrap items-center gap-1.5 text-xs">
                      {(['All', 'Orphans', 'Needy', 'General'] as const).map((filter) => (
                        <button
                          key={filter}
                          onClick={() => setAppFilter(filter)}
                          className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer ${
                            appFilter === filter
                              ? 'bg-[#0A192F] text-white shadow-2xs'
                              : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
                          }`}
                        >
                          {filter === 'Orphans' ? '100% Free Orphans' : filter === 'Needy' ? 'Sponsored Needy' : filter}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Search Bar */}
                  <div className="relative">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="text"
                      placeholder="Search by student name, mobile number, ID, or class level..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:outline-none"
                    />
                  </div>

                  {/* Applications Table / Cards */}
                  <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-2xs">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead>
                          <tr className="bg-stone-50 border-b border-stone-200 text-slate-500 uppercase tracking-wider text-[11px]">
                            <th className="py-3 px-4 font-semibold">Ref ID</th>
                            <th className="py-3 px-4 font-semibold">Student & Parent</th>
                            <th className="py-3 px-4 font-semibold">Category</th>
                            <th className="py-3 px-4 font-semibold">Class / Course</th>
                            <th className="py-3 px-4 font-semibold">Contact</th>
                            <th className="py-3 px-4 font-semibold">Status</th>
                            <th className="py-3 px-4 font-semibold text-right">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-stone-100">
                          {filteredApps.length === 0 ? (
                            <tr>
                              <td colSpan={7} className="py-8 text-center text-slate-400">
                                No admission applications matching current filter.
                              </td>
                            </tr>
                          ) : (
                            filteredApps.map((app) => (
                              <tr key={app.id} className="hover:bg-blue-50/40 transition-colors">
                                <td className="py-3 px-4 font-mono font-bold text-slate-900">{app.id}</td>
                                <td className="py-3 px-4">
                                  <p className="font-bold text-slate-900">{app.studentName}</p>
                                  <p className="text-[11px] text-slate-500">Guardian: {app.parentName}</p>
                                </td>
                                <td className="py-3 px-4">
                                  <span
                                    className={`inline-block px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                                      app.category.includes('Orphans')
                                        ? 'bg-rose-100 text-rose-800'
                                        : app.category.includes('Needy')
                                        ? 'bg-amber-100 text-amber-800'
                                        : 'bg-blue-100 text-blue-800'
                                    }`}
                                  >
                                    {app.category.includes('Orphans')
                                      ? '100% Free Orphan'
                                      : app.category.includes('Needy')
                                      ? '100% Sponsored Needy'
                                      : 'General'}
                                  </span>
                                </td>
                                <td className="py-3 px-4">
                                  <p className="font-semibold text-slate-800">{app.classLevel}</p>
                                  <p className="text-[11px] text-slate-500 truncate max-w-[180px]">{app.courseInterest}</p>
                                </td>
                                <td className="py-3 px-4">
                                  <a
                                    href={`tel:${app.mobileNumber}`}
                                    className="font-mono text-blue-700 hover:underline block"
                                  >
                                    {app.mobileNumber}
                                  </a>
                                  <a
                                    href={`https://wa.me/${app.mobileNumber.replace(/[^0-9]/g, '')}?text=Hello%20${encodeURIComponent(app.studentName)},%20this%20is%20from%20Agra%20Pujya%20Institute%20regarding%20your%20admission%20application`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="text-[10px] text-emerald-600 font-bold hover:underline inline-flex items-center gap-1 mt-0.5"
                                  >
                                    <span>WhatsApp</span>
                                    <ExternalLink className="w-2.5 h-2.5" />
                                  </a>
                                </td>
                                <td className="py-3 px-4">
                                  <select
                                    value={app.status}
                                    onChange={(e) => handleUpdateAppStatus(app.id, e.target.value as ApplicationStatus)}
                                    className="px-2 py-1 bg-stone-100 border border-stone-300 rounded font-semibold text-[11px] focus:outline-none focus:ring-1 focus:ring-blue-600 cursor-pointer"
                                  >
                                    <option value="Under Review">Under Review</option>
                                    <option value="Approved for Free Education">Approved for Free Education</option>
                                    <option value="Enrolled">Enrolled</option>
                                    <option value="Contacted">Contacted</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Archived">Archived</option>
                                  </select>
                                </td>
                                <td className="py-3 px-4 text-right">
                                  <div className="flex items-center justify-end gap-1.5">
                                    <button
                                      onClick={() => handleAdmitFromApplication(app)}
                                      title="Admit to Student Register"
                                      className="px-2 py-1 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                                    >
                                      <UserPlus className="w-3.5 h-3.5" />
                                      <span>Admit</span>
                                    </button>
                                    <button
                                      onClick={() => setSelectedApp(app)}
                                      title="View Application Details"
                                      className="px-2 py-1 text-xs font-semibold text-blue-700 hover:bg-blue-50 border border-blue-200 rounded-lg transition-colors cursor-pointer"
                                    >
                                      Details
                                    </button>
                                    <button
                                      onClick={() => handleDeleteApplication(app.id)}
                                      title="Delete Application"
                                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: BANK & QR CODE DONATION SETTINGS (CRITICAL NEW FEATURE) */}
              {activeTab === 'bank-qr' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
                      <QrCode className="w-6 h-6 text-amber-500" />
                      <span>Bank & QR Code Support Configuration</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">
                      Add or update your official QR Code, Bank Account Number, IFSC, and UPI ID. Changes appear live on the website instantly.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    {/* Left Form: Bank Details Editing */}
                    <form onSubmit={handleSaveBankDetails} className="lg:col-span-7 bg-stone-50 border border-stone-200 rounded-2xl p-6 space-y-4 text-xs">
                      <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                        <span className="font-bold text-slate-800 text-sm">Account & UPI Credentials</span>
                        <label className="flex items-center gap-2 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={bankForm.active}
                            onChange={(e) => setBankForm({ ...bankForm, active: e.target.checked })}
                            className="rounded text-blue-600 focus:ring-blue-500"
                          />
                          <span className="font-semibold text-slate-700">Display on Website</span>
                        </label>
                      </div>

                      {/* Account Holder Name */}
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Account Holder Name *
                        </label>
                        <input
                          type="text"
                          required
                          value={bankForm.accountName}
                          onChange={(e) => setBankForm({ ...bankForm, accountName: e.target.value })}
                          placeholder="AGRA PUJYA INSTITUTE"
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-semibold text-slate-900"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Bank Name */}
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Bank Name *
                          </label>
                          <input
                            type="text"
                            required
                            value={bankForm.bankName}
                            onChange={(e) => setBankForm({ ...bankForm, bankName: e.target.value })}
                            placeholder="State Bank of India / ICICI Bank"
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                          />
                        </div>

                        {/* Branch */}
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Branch Location *
                          </label>
                          <input
                            type="text"
                            required
                            value={bankForm.branch}
                            onChange={(e) => setBankForm({ ...bankForm, branch: e.target.value })}
                            placeholder="Hinjilicut Branch, Ganjam, Odisha"
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {/* Account Number */}
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            Account Number *
                          </label>
                          <input
                            type="text"
                            required
                            value={bankForm.accountNumber}
                            onChange={(e) => setBankForm({ ...bankForm, accountNumber: e.target.value })}
                            placeholder="e.g. 41238910293"
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                          />
                        </div>

                        {/* IFSC Code */}
                        <div>
                          <label className="block font-semibold text-slate-700 mb-1">
                            IFSC Code *
                          </label>
                          <input
                            type="text"
                            required
                            value={bankForm.ifscCode}
                            onChange={(e) => setBankForm({ ...bankForm, ifscCode: e.target.value })}
                            placeholder="e.g. SBIN0001234 / ICIC0001234"
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono uppercase"
                          />
                        </div>
                      </div>

                      {/* UPI ID */}
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">
                          Official UPI ID / VPA *
                        </label>
                        <input
                          type="text"
                          required
                          value={bankForm.upiId}
                          onChange={(e) => setBankForm({ ...bankForm, upiId: e.target.value })}
                          placeholder="e.g. agrapujyainstitute@sbi or 8339888551@upi"
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                        />
                      </div>

                      {/* QR Code Upload / Link */}
                      <div className="pt-2 border-t border-stone-200 space-y-3">
                        <label className="block font-semibold text-slate-700">
                          Custom QR Code Image (Upload from phone/laptop OR Image URL)
                        </label>
                        <div className="flex flex-col sm:flex-row gap-3 items-center">
                          <label className="w-full sm:w-auto px-4 py-2.5 bg-blue-50 border border-blue-200 text-blue-700 hover:bg-blue-100 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors shrink-0">
                            <Upload className="w-4 h-4" />
                            <span>Upload QR Code Image</span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleQRImageUpload}
                              className="hidden"
                            />
                          </label>
                          <span className="text-slate-400 text-[11px]">or</span>
                          <input
                            type="text"
                            value={bankForm.qrCodeImage || ''}
                            onChange={(e) => setBankForm({ ...bankForm, qrCodeImage: e.target.value })}
                            placeholder="Paste image URL (Optional)"
                            className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none text-[11px]"
                          />
                        </div>
                        {bankForm.qrCodeImage && (
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] text-emerald-600 font-semibold">Custom QR Code Loaded</span>
                            <button
                              type="button"
                              onClick={() => setBankForm({ ...bankForm, qrCodeImage: '' })}
                              className="text-[10px] text-rose-600 hover:underline"
                            >
                              Reset to Dynamic UPI QR
                            </button>
                          </div>
                        )}
                      </div>

                      <div className="pt-3">
                        <button
                          type="submit"
                          className="w-full py-3 px-4 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
                        >
                          <Save className="w-4 h-4" />
                          <span>Save & Publish Bank & QR Details Live</span>
                        </button>
                      </div>
                    </form>

                    {/* Right Column: Live Website Card Preview */}
                    <div className="lg:col-span-5 bg-[#0A192F] text-white p-6 rounded-2xl border border-amber-400/30 shadow-xl space-y-4">
                      <div className="flex items-center justify-between pb-3 border-b border-white/10">
                        <span className="text-xs uppercase tracking-wider font-bold text-amber-300">
                          Live Donor Preview
                        </span>
                        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-400/30">
                          What Donors See
                        </span>
                      </div>

                      <div className="bg-white p-4 rounded-xl text-center text-slate-900 max-w-[220px] mx-auto shadow-md">
                        <div className="w-36 h-36 bg-stone-100 rounded-lg overflow-hidden mx-auto flex items-center justify-center">
                          <img
                            src={
                              bankForm.qrCodeImage && bankForm.qrCodeImage.trim()
                                ? bankForm.qrCodeImage
                                : `https://api.qrserver.com/v1/create-qr-code/?size=250x250&margin=8&data=${encodeURIComponent(
                                    `upi://pay?pa=${bankForm.upiId || 'agrapujyainstitute@sbi'}&pn=${encodeURIComponent(
                                      bankForm.accountName || 'AGRA PUJYA INSTITUTE'
                                    )}&cu=INR`
                                  )}`
                            }
                            alt="QR Preview"
                            className="w-full h-full object-contain"
                          />
                        </div>
                        <p className="text-[11px] font-bold text-slate-900 mt-2">Scan & Pay via UPI</p>
                        <p className="text-[10px] text-slate-500">PhonePe · GPay · Paytm</p>
                      </div>

                      <div className="space-y-2 text-xs">
                        <div className="bg-white/5 p-2.5 rounded-lg border border-white/10">
                          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Account Holder</span>
                          <span className="font-bold text-white text-xs">{bankForm.accountName}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-white/5 p-2 rounded-lg border border-white/10">
                            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Bank</span>
                            <span className="font-semibold text-white text-xs">{bankForm.bankName}</span>
                          </div>
                          <div className="bg-white/5 p-2 rounded-lg border border-white/10">
                            <span className="text-[10px] text-slate-400 uppercase font-semibold block">IFSC Code</span>
                            <span className="font-mono font-bold text-amber-300 text-xs">{bankForm.ifscCode}</span>
                          </div>
                        </div>
                        <div className="bg-white/5 p-2.5 rounded-lg border border-white/10 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] text-slate-400 uppercase font-semibold block">Account Number</span>
                            <span className="font-mono font-bold text-white text-xs tracking-wider">{bankForm.accountNumber}</span>
                          </div>
                          <span className="text-[10px] bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded font-medium">1-Click Copy</span>
                        </div>
                        <div className="bg-white/5 p-2.5 rounded-lg border border-blue-400/30 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] text-blue-300 uppercase font-semibold block">UPI ID / VPA</span>
                            <span className="font-mono font-bold text-white text-xs">{bankForm.upiId}</span>
                          </div>
                          <span className="text-[10px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded font-medium">1-Click Copy</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: ACTIVITIES GALLERY MANAGEMENT */}
              {activeTab === 'gallery' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-slate-900">
                      Institute Activities & Gallery Photos
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Add new photos of orphan coaching, classroom sessions, computer training, or events.
                    </p>
                  </div>

                  {/* Add New Gallery Photo Form */}
                  <form onSubmit={handleAddGallery} className="bg-stone-50 border border-stone-200 rounded-2xl p-5 space-y-4 text-xs">
                    <span className="font-bold text-slate-800 text-sm block">Add New Activity Photo</span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Photo Title *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Science Laboratory Workshop"
                          value={newGallery.title}
                          onChange={(e) => setNewGallery({ ...newGallery, title: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Category *</label>
                        <select
                          value={newGallery.category}
                          onChange={(e) => setNewGallery({ ...newGallery, category: e.target.value as any })}
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                        >
                          <option value="Classroom Activities">Classroom Activities</option>
                          <option value="Students Learning">Students Learning</option>
                          <option value="Computer Education">Computer Education</option>
                          <option value="Educational Events">Educational Events</option>
                          <option value="Community Activities">Community Activities</option>
                          <option value="Institute Facilities">Institute Facilities</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Image Source (Upload Photo OR Enter URL) *</label>
                      <div className="flex flex-col sm:flex-row gap-3 items-center">
                        <label className="w-full sm:w-auto px-4 py-2 bg-blue-50 border border-blue-200 text-blue-700 hover:bg-blue-100 rounded-xl font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors shrink-0">
                          <Upload className="w-4 h-4" />
                          <span>Upload From Phone / PC</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleGalleryImageUpload}
                            className="hidden"
                          />
                        </label>
                        <span className="text-slate-400 text-xs">or</span>
                        <input
                          type="text"
                          placeholder="/assets/images/... or https://..."
                          value={newGallery.image}
                          onChange={(e) => setNewGallery({ ...newGallery, image: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none text-xs"
                        />
                      </div>
                      {newGallery.image && (
                        <div className="mt-2 flex items-center gap-3">
                          <img src={newGallery.image} alt="Preview" className="w-12 h-12 object-cover rounded-lg border border-stone-300" />
                          <span className="text-[11px] text-emerald-600 font-semibold">Image ready for publishing</span>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Caption / Description</label>
                      <input
                        type="text"
                        placeholder="Brief narrative of the educational activity shown in the photo"
                        value={newGallery.caption}
                        onChange={(e) => setNewGallery({ ...newGallery, caption: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="py-2.5 px-4 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors cursor-pointer flex items-center gap-2"
                    >
                      <Upload className="w-4 h-4" />
                      <span>Upload & Add to Gallery</span>
                    </button>
                  </form>

                  {/* Existing Gallery Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {galleryItems.map((item) => (
                      <div key={item.id} className="bg-stone-50 rounded-xl border border-stone-200 overflow-hidden shadow-2xs group flex flex-col justify-between">
                        <div>
                          <div className="aspect-video bg-stone-200 overflow-hidden relative">
                            <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                            <span className="absolute top-2 left-2 text-[10px] font-bold uppercase tracking-wider bg-black/70 text-white px-2 py-0.5 rounded">
                              {item.category}
                            </span>
                          </div>
                          <div className="p-3.5">
                            <h4 className="font-bold text-sm text-slate-900">{item.title}</h4>
                            <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{item.caption}</p>
                          </div>
                        </div>
                        <div className="p-3.5 pt-0 flex justify-end">
                          <button
                            onClick={() => handleDeleteGallery(item.id)}
                            className="text-xs text-rose-600 hover:text-rose-800 flex items-center gap-1 font-semibold cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Remove Photo</span>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: ANNOUNCEMENTS / NOTICES */}
              {activeTab === 'announcements' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-slate-900">
                      Top Announcement & Notice Banners
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Publish urgent notifications for free orphan admissions, scholarship deadlines, or exam batches.
                    </p>
                  </div>

                  <form onSubmit={handleAddAnnouncement} className="bg-stone-50 border border-stone-200 rounded-2xl p-5 space-y-4 text-xs">
                    <span className="font-bold text-slate-800 text-sm block">Add New Notice</span>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="sm:col-span-2">
                        <label className="block font-semibold text-slate-700 mb-1">Headline *</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Free Education Admissions Open for 2026–27"
                          value={newAnn.title}
                          onChange={(e) => setNewAnn({ ...newAnn, title: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Priority</label>
                        <select
                          value={newAnn.priority}
                          onChange={(e) => setNewAnn({ ...newAnn, priority: e.target.value as any })}
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                        >
                          <option value="urgent">Urgent (Gold Badge)</option>
                          <option value="normal">Standard Notice</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Notice Details *</label>
                      <textarea
                        required
                        rows={2}
                        placeholder="Details of the announcement displayed in the top banner"
                        value={newAnn.content}
                        onChange={(e) => setNewAnn({ ...newAnn, content: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>
                    <button
                      type="submit"
                      className="py-2.5 px-4 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors cursor-pointer flex items-center gap-2"
                    >
                      <Bell className="w-4 h-4" />
                      <span>Publish Announcement</span>
                    </button>
                  </form>

                  <div className="space-y-3">
                    {announcements.map((ann) => (
                      <div key={ann.id} className="p-4 rounded-xl border border-stone-200 bg-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                              ann.priority === 'urgent' ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-blue-100 text-blue-900'
                            }`}>
                              {ann.priority}
                            </span>
                            <h4 className="font-bold text-sm text-slate-900">{ann.title}</h4>
                          </div>
                          <p className="text-xs text-slate-600 mt-1">{ann.content}</p>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                          <button
                            onClick={() => handleToggleAnnouncement(ann.id)}
                            className={`px-3 py-1 rounded text-xs font-bold cursor-pointer ${
                              ann.active ? 'bg-emerald-100 text-emerald-800' : 'bg-stone-200 text-slate-600'
                            }`}
                          >
                            {ann.active ? 'Active' : 'Hidden'}
                          </button>
                          <button
                            onClick={() => handleDeleteAnnouncement(ann.id)}
                            className="p-1.5 text-rose-600 hover:text-rose-800 rounded hover:bg-rose-50 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: CONTACT INQUIRIES */}
              {activeTab === 'messages' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-slate-900">
                      Website Contact Inquiries
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Messages submitted by parents, students, and community supporters.
                    </p>
                  </div>

                  <div className="space-y-3">
                    {messages.length === 0 ? (
                      <div className="text-center py-12 text-slate-400 text-xs">
                        No contact inquiries received yet.
                      </div>
                    ) : (
                      messages.map((msg) => (
                        <div key={msg.id} className="p-4 rounded-xl border border-stone-200 bg-stone-50 space-y-2 text-xs">
                          <div className="flex items-start justify-between">
                            <div>
                              <span className="font-bold text-slate-900 text-sm">{msg.name}</span>
                              <span className="text-slate-500 ml-2">· {msg.phone}</span>
                              {msg.email && <span className="text-blue-700 ml-2">· {msg.email}</span>}
                            </div>
                            <span className="text-[10px] text-slate-400">
                              {new Date(msg.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="font-semibold text-slate-800">Subject: {msg.subject}</p>
                          <p className="text-slate-600 leading-relaxed bg-white p-3 rounded-lg border border-stone-200">
                            {msg.message}
                          </p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* TAB 6: SECURITY & PASSWORD SETTINGS */}
              {activeTab === 'security' && (
                <div className="space-y-6 max-w-xl">
                  <div>
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
                      <Shield className="w-6 h-6 text-blue-700" />
                      <span>Security & Password Management</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Keep your portal safe. Only authorized personnel should possess these credentials.
                    </p>
                  </div>

                  <form onSubmit={handleUpdatePassword} className="bg-stone-50 border border-stone-200 rounded-2xl p-6 space-y-4 text-xs">
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Administrator ID (Email) *</label>
                      <input
                        type="email"
                        required
                        value={securityForm.email}
                        onChange={(e) => setSecurityForm({ ...securityForm, email: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Current Password *</label>
                      <input
                        type="password"
                        required
                        placeholder="Enter current password"
                        value={securityForm.currentPassword}
                        onChange={(e) => setSecurityForm({ ...securityForm, currentPassword: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">New Password *</label>
                        <input
                          type="password"
                          required
                          placeholder="At least 6 characters"
                          value={securityForm.newPassword}
                          onChange={(e) => setSecurityForm({ ...securityForm, newPassword: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                        />
                      </div>

                      <div>
                        <label className="block font-semibold text-slate-700 mb-1">Confirm New Password *</label>
                        <input
                          type="password"
                          required
                          placeholder="Re-type new password"
                          value={securityForm.confirmPassword}
                          onChange={(e) => setSecurityForm({ ...securityForm, confirmPassword: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-stone-300 rounded-lg focus:ring-2 focus:ring-blue-600 focus:outline-none font-mono"
                        />
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="py-2.5 px-4 text-xs font-bold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors cursor-pointer flex items-center gap-2"
                      >
                        <Lock className="w-4 h-4" />
                        <span>Update Security Credentials</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Application Details Modal */}
      {selectedApp && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 space-y-4 text-xs max-h-[85vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b pb-3 border-stone-200">
              <div>
                <span className="font-mono font-bold text-blue-700">Ref: {selectedApp.id}</span>
                <h4 className="font-bold text-lg text-slate-900 mt-0.5">{selectedApp.studentName}</h4>
              </div>
              <button onClick={() => setSelectedApp(null)} className="p-1 hover:bg-stone-100 rounded">
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Guardian / Parent</span>
                <span className="font-bold text-slate-800">{selectedApp.parentName}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Mobile / WhatsApp</span>
                <a href={`tel:${selectedApp.mobileNumber}`} className="font-bold text-blue-700">{selectedApp.mobileNumber}</a>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Category</span>
                <span className="font-bold text-rose-700">{selectedApp.category}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold block">Class & Medium</span>
                <span className="font-bold text-slate-800">{selectedApp.classLevel} ({selectedApp.medium})</span>
              </div>
            </div>

            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold block">Course Enquired</span>
              <span className="font-semibold text-slate-900">{selectedApp.courseInterest}</span>
            </div>

            <div>
              <span className="text-slate-400 text-[10px] uppercase font-bold block">Address</span>
              <span className="text-slate-700">{selectedApp.address}</span>
            </div>

            {selectedApp.additionalInfo && (
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900">
                <span className="font-bold block mb-1">Family Situation & Academic Details:</span>
                <p className="leading-relaxed">{selectedApp.additionalInfo}</p>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-stone-200">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    handleAdmitFromApplication(selectedApp);
                    setSelectedApp(null);
                  }}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Admit as Student</span>
                </button>
                <a
                  href={`https://wa.me/${selectedApp.mobileNumber.replace(/[^0-9]/g, '')}?text=Hello%20${encodeURIComponent(selectedApp.studentName)},%20this%20is%20from%20Agra%20Pujya%20Institute%20regarding%20your%20free%20education%20enquiry%20${selectedApp.id}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3.5 py-2 bg-slate-900 hover:bg-black text-white font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDeleteApplication(selectedApp.id)}
                  className="px-3 py-2 text-rose-600 hover:bg-rose-50 border border-rose-200 hover:border-rose-300 font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
                <button
                  onClick={() => setSelectedApp(null)}
                  className="px-4 py-2 bg-stone-200 hover:bg-stone-300 text-slate-700 font-semibold rounded-lg cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
